@echo off
REM ============================================================
REM  Crea FlappySpace.exe (no necesita Python para jugarlo)
REM  Solo hay que correr este archivo UNA vez en una PC con Python.
REM ============================================================
cd /d "%~dp0"

echo.
echo [1/3] Instalando PyInstaller y pygame-ce...
py -m pip install --upgrade pyinstaller pygame-ce
if errorlevel 1 goto error

echo.
echo [2/3] Construyendo FlappySpace.exe (tarda 1-2 minutos)...
py -m PyInstaller --noconfirm --clean --onefile --windowed ^
   --name FlappySpace --icon flappy_space.ico --exclude-module pkg_resources ^
   --add-data "assets;assets" ^
   --add-data "src\database\esquema.sql;src\database" ^
   --add-data "src\database\datos_iniciales.sql;src\database" ^
   main.py
if errorlevel 1 goto error

echo.
echo [3/3] Copiando el .exe a esta carpeta...
copy /y "dist\FlappySpace.exe" "FlappySpace.exe" >nul
rmdir /s /q build >nul 2>&1
rmdir /s /q dist >nul 2>&1
del /q FlappySpace.spec >nul 2>&1

echo.
echo ============================================================
echo  LISTO: FlappySpace.exe
echo  La base de datos flappy_space_bd.db se crea junto al .exe
echo ============================================================
pause
exit /b 0

:error
echo.
echo Hubo un error. Revisa que Python este instalado (comando: py --version).
pause
exit /b 1
