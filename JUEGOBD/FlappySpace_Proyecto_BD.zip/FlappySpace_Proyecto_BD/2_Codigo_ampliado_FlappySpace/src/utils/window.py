import pygame

from .constants import PISO_Y


class Window:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.ratio = width / height
        self.w = width
        self.h = height
        self.r = width / height
        self.viewport_width = width
        self.viewport_height = PISO_Y        # antes height * 0.79
        self.vw = width
        self.vh = PISO_Y
        self.viewport_ratio = self.vw / self.vh
        self.vr = self.vw / self.vh
        # NUEVO: se dibuja en un lienzo chico y se escala a la ventana (sin deformar pixeles)
        self.pantalla_completa = False
        self.display = None
        self.escala, self.ox, self.oy = 1, 0, 0
        self.abrir()

    def abrir(self):
        info = pygame.display.Info()
        if self.pantalla_completa:
            self.display = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        else:
            alto_libre = (info.current_h or 768) - 90         # deja espacio a la barra de tareas
            esc = max(1, min(4, alto_libre // self.height))
            self.display = pygame.display.set_mode((self.width * esc, self.height * esc))
        dw, dh = self.display.get_size()
        self.escala = max(1, min(dw // self.width, dh // self.height))
        self.ox = (dw - self.width * self.escala) // 2
        self.oy = (dh - self.height * self.escala) // 2

    def cambiar_pantalla(self, completa):
        if completa != self.pantalla_completa:
            self.pantalla_completa = completa
            self.abrir()

    def mostrar(self, lienzo):
        """Escala el lienzo (144x256) al tamano de la ventana con numeros enteros."""
        self.display.fill((0, 0, 0))
        img = pygame.transform.scale(lienzo, (self.width * self.escala, self.height * self.escala))
        self.display.blit(img, (self.ox, self.oy))
        pygame.display.update()

    def a_lienzo(self, pos):
        """Pasa una posicion de la ventana (raton) a pixeles del juego."""
        return ((pos[0] - self.ox) // self.escala, (pos[1] - self.oy) // self.escala)
