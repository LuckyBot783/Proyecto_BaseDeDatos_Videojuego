"""
CONSTANTES. El codigo original (FlapPyBird) usaba 288x512 vertical a 30 FPS.
Flappy Space usa una pantalla de PC horizontal de 320x180 (pixel art que se
escala x2, x3 o x4 a la ventana) a 60 FPS, con la fisica de Flappy Space.
"""
ANCHO, ALTO = 320, 180
PISO_Y = 156              # donde empieza el piso (antes: 79% del alto)
FPS = 60
TITULO = "Flappy Space - Proyecto Base de Datos"

# carpetas de imagenes y sonidos (los nombres de nave, escenario y tubo vienen de la BD)
NAVES = "assets/naves/"
TUBOS = "assets/tubos/"
FONDO = "assets/fondo/"
OBJETOS = "assets/objetos/"
EFECTOS = "assets/efectos/"
UI = "assets/ui/"
AUDIO = "assets/audio/"
MUSICA = "assets/musica/"
POSES = ("nave_sube", "nave", "nave_cae")

VEL_TUBOS = 1.3           # original: 5 px por cuadro
SEPARACION = 98           # distancia entre un par de tubos y el siguiente

# fisica de la nave (original entre parentesis)
NORMAL = {"vel_y": -3.0,      # (-9) velocidad al propulsar
          "max_vel_y": 4.2,   # (10) caida maxima
          "min_vel_y": -3.0,  # (-8) subida maxima
          "acc_y": 0.18}      # (1)  gravedad
FLOTAR = {"vel_y": 0.25, "max_vel_y": 1.0, "min_vel_y": -1.0, "acc_y": 0.0625}
CHOQUE = {"acc_y": 0.25, "vel_y": 1.0, "max_vel_y": 5.0, "vel_rot": -6}

# paleta de Flappy Space
FONDO_COLOR = (7, 6, 20)
NAVY = (22, 26, 64)
DEEP = (38, 42, 110)
BLUE = (40, 110, 220)
SKY = (48, 168, 236)
CYAN = (70, 220, 245)
MAG = (235, 60, 205)
PINK = (255, 150, 235)
PURP = (112, 46, 162)
WHITE = (232, 244, 255)
GOLD = (244, 196, 64)
LIME = (150, 236, 84)
