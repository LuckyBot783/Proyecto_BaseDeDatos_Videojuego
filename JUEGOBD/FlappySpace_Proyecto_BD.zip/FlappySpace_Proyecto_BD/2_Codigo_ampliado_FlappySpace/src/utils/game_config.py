import os

import pygame

from .images import Images
from .sounds import Sounds
from .window import Window


class GameConfig:
    def __init__(
        self,
        screen: pygame.Surface,
        clock: pygame.time.Clock,
        fps: int,
        window: Window,
        images: Images,
        sounds: Sounds,
    ) -> None:
        self.screen = screen          # ahora es el lienzo de 144x256 (no la ventana)
        self.clock = clock
        self.fps = fps
        self.window = window
        self.images = images
        self.sounds = sounds
        self.debug = os.environ.get("DEBUG", False)

    def tick(self) -> None:
        self.window.mostrar(self.screen)   # NUEVO: escalar el lienzo a la ventana
        self.clock.tick(self.fps)
