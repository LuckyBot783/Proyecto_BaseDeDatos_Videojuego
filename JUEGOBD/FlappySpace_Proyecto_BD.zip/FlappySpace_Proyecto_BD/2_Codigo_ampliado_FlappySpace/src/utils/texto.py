"""
NUEVO: texto pixel 5x7 leido de assets/ui/fuente.png (solo mayusculas, numeros y signos).
"""
import unicodedata

import pygame

LETRAS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.:-!?/><+,'()=_*#%"


def limpiar(texto):
    """Mayusculas y sin acentos (la fuente no tiene acentos ni minusculas)."""
    texto = unicodedata.normalize("NFD", str(texto).replace("ñ", "n").replace("Ñ", "N"))
    return "".join(c for c in texto if unicodedata.category(c) != "Mn").upper()


class Fuente:
    def __init__(self, imagen):
        self.imagen = imagen
        self.cache = {}

    def letra(self, ch, color):
        clave = (ch, color)
        if clave not in self.cache:
            s = pygame.Surface((5, 7), pygame.SRCALPHA)
            i = LETRAS.find(ch)
            if i < 0:
                i = LETRAS.index("?")
            for y in range(7):
                for x in range(5):
                    if self.imagen.get_at((i * 6 + x, y)).a > 0:
                        s.set_at((x, y), color)
            self.cache[clave] = s
        return self.cache[clave]

    @staticmethod
    def ancho(texto):
        return len(texto) * 6 - 1 if texto else 0

    def dibujar(self, sup, texto, x, y, color, alinear="i", sombra=None):
        """alinear: 'i' izquierda, 'c' centro, 'd' derecha."""
        texto = limpiar(texto)
        w = self.ancho(texto)
        x = x - w // 2 if alinear == "c" else x - w if alinear == "d" else x
        for i, ch in enumerate(texto):
            if ch != " ":
                if sombra:
                    sup.blit(self.letra(ch, sombra), (x + i * 6, y + 1))
                sup.blit(self.letra(ch, color), (x + i * 6, y))
        return w
