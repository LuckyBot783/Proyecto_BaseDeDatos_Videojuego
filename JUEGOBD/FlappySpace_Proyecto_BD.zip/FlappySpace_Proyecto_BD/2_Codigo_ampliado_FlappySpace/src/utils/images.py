from typing import List, Tuple

import pygame

from .constants import EFECTOS, FONDO, NAVES, OBJETOS, POSES, TUBOS, UI


def cargar(ruta):
    return pygame.image.load(ruta).convert_alpha()


def lienzo(img, w, h):
    """Centra una imagen en un lienzo de w x h (asi las 3 poses de la nave miden igual)."""
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    s.blit(img, ((w - img.get_width()) // 2, (h - img.get_height()) // 2))
    return s


class Images:
    numbers: List[pygame.Surface]
    game_over: pygame.Surface
    welcome_message: pygame.Surface
    base: pygame.Surface
    player: Tuple[pygame.Surface]
    pipe: Tuple[pygame.Surface]

    def __init__(self) -> None:
        self.numbers = [cargar(f"{UI}num_{num}.png") for num in range(10)]
        self.game_over = cargar(UI + "gameover.png")
        self.welcome_message = cargar(UI + "listo.png")
        # piso: el mosaico de 16 px se repite a lo ancho (+16 para que pueda desplazarse)
        piso = cargar(FONDO + "piso.png")
        self.base = pygame.Surface((320 + 16, piso.get_height()), pygame.SRCALPHA)
        for x in range(0, self.base.get_width(), 16):
            self.base.blit(piso, (x, 0))
        # NUEVO: fondo espacial en capas (Flappy Space)
        self.estrellas = [cargar(f"{FONDO}estrellas_{i}.png") for i in (1, 2, 3)]
        self.brillo = cargar(FONDO + "brillo.png")
        self.planeta = cargar(FONDO + "planeta.png")
        self.techo = [cargar(FONDO + "techo_1.png"), cargar(FONDO + "techo_2.png")]
        self.asteroides = [cargar(f"{OBJETOS}asteroide_{i}.png") for i in (1, 2, 3)]
        self.fuego = [cargar(EFECTOS + "fuego_1.png"), cargar(EFECTOS + "fuego_2.png")]
        # NUEVO: interfaz
        self.titulo = cargar(UI + "titulo.png")
        self.pausa = cargar(UI + "pausa.png")
        self.panel = cargar(UI + "panel.png")
        self.tabla = cargar(UI + "tabla.png")
        self.boton = cargar(UI + "boton.png")
        self.boton_sel = cargar(UI + "boton_sel.png")
        self.campo = cargar(UI + "campo.png")
        self.campo_sel = cargar(UI + "campo_sel.png")
        self.fuente = cargar(UI + "fuente.png")
        self.medallas = {m: cargar(f"{UI}medalla_{m}.png") for m in ("bronce", "plata", "oro", "platino")}
        self.naves = {}
        self.preparar({"escenario": (1, "planeta.png"), "tubo": (1, "tech"), "nave": (1, "CLASICA", "clasica")})

    def nave(self, carpeta):
        """Las 3 poses (sube, normal, cae) de una nave, todas de 22x14."""
        if carpeta not in self.naves:
            self.naves[carpeta] = tuple(lienzo(cargar(f"{NAVES}{carpeta}/{p}.png"), 22, 14) for p in POSES)
        return self.naves[carpeta]

    def preparar(self, sorteo):
        """Antes era randomize(): ahora escenario, nave y tubo los elige la base de datos."""
        self.escenario = sorteo["escenario"][1]
        self.player = self.nave(sorteo["nave"][2])
        estilo = sorteo["tubo"][1]
        self.pipe = (cargar(f"{TUBOS}{estilo}_arriba.png"), cargar(f"{TUBOS}{estilo}_abajo.png"))
