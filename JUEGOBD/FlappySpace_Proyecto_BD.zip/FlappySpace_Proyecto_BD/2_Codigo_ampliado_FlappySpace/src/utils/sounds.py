import pygame

from .constants import AUDIO, MUSICA


class Sonido:
    """NUEVO: si la PC no tiene audio, el juego sigue sin sonido en vez de cerrarse."""
    def __init__(self, archivo, sounds):
        self.s = pygame.mixer.Sound(AUDIO + archivo) if sounds.ok else None
        self.sounds = sounds

    def play(self):
        if self.s and self.sounds.volumen > 0:
            self.s.set_volume(self.sounds.volumen)
            self.s.play()


class Sounds:
    die: Sonido
    hit: Sonido
    point: Sonido
    swoosh: Sonido
    wing: Sonido

    def __init__(self) -> None:
        try:
            pygame.mixer.init()
            self.ok = True
        except pygame.error:
            self.ok = False
        self.volumen = 0.8
        self.die = Sonido("die.wav", self)
        self.hit = Sonido("hit.wav", self)
        self.point = Sonido("point.wav", self)
        self.swoosh = Sonido("swoosh.wav", self)
        self.wing = Sonido("wing.wav", self)
        # NUEVO: sonidos de menus
        self.mover = Sonido("mover.wav", self)
        self.aceptar = Sonido("aceptar.wav", self)
        self.atras = Sonido("atras.wav", self)
        self.record = Sonido("record.wav", self)
        # NUEVO: musica de Flappy Space (canal 0 reservado)
        self.musica = {}
        self.pista = None
        self.vol_musica = 0.6
        if self.ok:
            pygame.mixer.set_reserved(1)
            self.canal = pygame.mixer.Channel(0)
            for nombre in ("menu", "juego"):
                self.musica[nombre] = pygame.mixer.Sound(MUSICA + nombre + ".wav")

    def tocar(self, nombre):
        """Cambia la pista de musica (si ya suena, no hace nada)."""
        if self.ok and nombre != self.pista:
            self.pista = nombre
            self.canal.play(self.musica[nombre], loops=-1, fade_ms=500)
            self.canal.set_volume(self.vol_musica)

    def volumen_musica(self, v):
        self.vol_musica = v
        if self.ok:
            self.canal.set_volume(v)
