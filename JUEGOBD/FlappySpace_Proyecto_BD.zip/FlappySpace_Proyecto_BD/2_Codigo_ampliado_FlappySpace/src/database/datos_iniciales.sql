-- =====================================================================
--  FLAPPY SPACE - Datos iniciales (catalogos)
--  Se insertan solo la primera vez (INSERT OR IGNORE).
-- =====================================================================
INSERT OR IGNORE INTO NAVE VALUES
 (1, 'CLASICA', 'clasica', 'Nave azul marino con cabina cyan'),
 (2, 'FENIX',   'fenix',   'Nave naranja con alas de fuego'),
 (3, 'OVNI',    'ovni',    'Platillo volador verde'),
 (4, 'COHETE',  'cohete',  'Cohete blanco con franjas rojas'),
 (5, 'MANTA',   'manta',   'Nave morada en forma de manta raya'),
 (6, 'SOMBRA',  'sombra',  'Nave gris de sigilo');

-- colores reales de cada sprite (atributo multivaluado)
INSERT OR IGNORE INTO NAVE_COLOR VALUES
 (1, '#1E2460'), (1, '#46DCF5'), (1, '#EB3CCD'),
 (2, '#F07628'), (2, '#781C28'), (2, '#FFDE60'),
 (3, '#54D68C'), (3, '#1A4640'), (3, '#DEFFCE'),
 (4, '#6E1E34'), (4, '#ECECF6'), (4, '#E83E48'),
 (5, '#9646DE'), (5, '#3A145C'), (5, '#F49CFF'),
 (6, '#768096'), (6, '#282C3E'), (6, '#E8F0FF');

INSERT OR IGNORE INTO ESCENARIO VALUES
 (1, 'ORBITA',   'planeta.png',     '#070614', 'Estrellas y un planeta con anillo a lo lejos'),
 (2, 'CINTURON', 'asteroide_1.png', '#070614', 'Cinturon de asteroides que flotan'),
 (3, 'TORMENTA', 'techo_1.png',     '#070614', 'Techo electrico y estrellas que brillan');

INSERT OR IGNORE INTO TUBO VALUES
 (1, 'TECH',  'tech',  '#46DCF5', 'Tubo metalico con luces cyan'),
 (2, 'NEON',  'neon',  '#EB3CCD', 'Tubo de neon rosa'),
 (3, 'OXIDO', 'oxido', '#CE6A2C', 'Tubo viejo y oxidado');

-- que tubos salen en cada escenario y con que probabilidad (hueco = espacio para pasar)
INSERT OR IGNORE INTO TUBO_ESCENARIO VALUES
 (1, 1, 0.60, 56), (2, 1, 0.30, 56), (3, 1, 0.10, 56),
 (1, 2, 0.30, 56), (2, 2, 0.10, 56), (3, 2, 0.60, 56),
 (1, 3, 0.20, 56), (2, 3, 0.60, 56), (3, 3, 0.20, 56);

INSERT OR IGNORE INTO MEDALLA VALUES
 (1, 'BRONCE',  10, 'medalla_bronce.png',  'Pasar 10 tubos en una partida'),
 (2, 'PLATA',   20, 'medalla_plata.png',   'Pasar 20 tubos en una partida'),
 (3, 'ORO',     30, 'medalla_oro.png',     'Pasar 30 tubos en una partida'),
 (4, 'PLATINO', 40, 'medalla_platino.png', 'Pasar 40 tubos en una partida');

INSERT OR IGNORE INTO MENU VALUES
 (1,  'LOGIN',        'USUARIOS',        'Elegir jugador o crear uno nuevo'),
 (2,  'REGISTRO',     'NUEVO JUGADOR',   'Captura de alias, nombre y apellido'),
 (3,  'PRINCIPAL',    'MENU PRINCIPAL',  'Menu con todas las opciones del juego'),
 (4,  'JUEGO',        'PARTIDA',         'Pantalla donde se juega (listo y vuelo)'),
 (5,  'PAUSA',        'PAUSA',           'Partida detenida'),
 (6,  'FIN',          'FIN DE PARTIDA',  'Puntaje, record, medalla y resultado'),
 (7,  'LEADERBOARD',  'LEADERBOARD',     'Las 10 mejores partidas'),
 (8,  'ESTADISTICAS', 'ESTADISTICAS',    'Progreso, desempeno y comportamiento'),
 (9,  'AJUSTES',      'AJUSTES',         'Volumen, musica, pantalla, FPS y nave'),
 (10, 'CONTROLES',    'CONTROLES',       'Teclas de cada pantalla'),
 (11, 'CREDITOS',     'CREDITOS',        'Integrantes del equipo');

INSERT OR IGNORE INTO MENU_OPCION VALUES
 (1, 'NUEVO JUGADOR', 1), (1, 'SALIR', 2),
 (2, 'ALIAS', 1), (2, 'NOMBRE', 2), (2, 'APELLIDO', 3), (2, 'CREAR', 4),
 (3, 'JUGAR', 1), (3, 'LEADERBOARD', 2), (3, 'ESTADISTICAS', 3), (3, 'AJUSTES', 4),
 (3, 'CONTROLES', 5), (3, 'CREDITOS', 6), (3, 'OTRO JUGADOR', 7), (3, 'SALIR', 8),
 (5, 'CONTINUAR', 1), (5, 'SALIR AL MENU', 2),
 (6, 'REINTENTAR', 1), (6, 'MENU', 2),
 (7, 'MEJORES PARTIDAS', 1), (7, 'MEJORES JUGADORES', 2),
 (8, 'MIS ESTADISTICAS', 1), (8, 'TODOS LOS JUGADORES', 2), (8, 'MEDALLAS', 3),
 (9, 'EFECTOS', 1), (9, 'MUSICA', 2), (9, 'PANTALLA COMPLETA', 3), (9, 'MOSTRAR FPS', 4),
 (9, 'NAVE', 5), (9, 'VOLVER', 6),
 (10, 'VOLVER', 1),
 (11, 'VOLVER', 1);

INSERT OR IGNORE INTO TECLA VALUES
 (1,  'ESPACIO',     'K_SPACE',     'TECLADO', 'Barra espaciadora'),
 (2,  'ARRIBA',      'K_UP',        'TECLADO', 'Flecha arriba'),
 (3,  'ABAJO',       'K_DOWN',      'TECLADO', 'Flecha abajo'),
 (4,  'IZQUIERDA',   'K_LEFT',      'TECLADO', 'Flecha izquierda'),
 (5,  'DERECHA',     'K_RIGHT',     'TECLADO', 'Flecha derecha'),
 (6,  'ENTER',       'K_RETURN',    'TECLADO', 'Tecla Enter'),
 (7,  'ESC',         'K_ESCAPE',    'TECLADO', 'Tecla Escape'),
 (8,  'P',           'K_p',         'TECLADO', 'Letra P'),
 (9,  'W',           'K_w',         'TECLADO', 'Letra W'),
 (10, 'S',           'K_s',         'TECLADO', 'Letra S'),
 (11, 'TAB',         'K_TAB',       'TECLADO', 'Tabulador'),
 (12, 'BORRAR',      'K_BACKSPACE', 'TECLADO', 'Retroceso'),
 (13, 'F11',         'K_F11',       'TECLADO', 'Tecla F11'),
 (14, 'LETRA/NUM',   'TEXTO',       'TECLADO', 'Cualquier letra o numero al escribir'),
 (15, 'OTRA TECLA',  'OTRA',        'TECLADO', 'Cualquier otra tecla'),
 (16, 'CLIC IZQ',    'BOTON_1',     'RATON',   'Boton izquierdo del raton'),
 (17, 'CLIC CENTRAL','BOTON_2',     'RATON',   'Boton central (rueda) del raton'),
 (18, 'CLIC DER',    'BOTON_3',     'RATON',   'Boton derecho del raton'),
 (19, 'TOQUE',       'FINGERDOWN',  'TACTIL',  'Toque en pantalla tactil');

INSERT OR IGNORE INTO MENU_TECLA VALUES
 -- JUEGO
 (4, 1, 'PROPULSAR', 1), (4, 2, 'PROPULSAR', 2), (4, 16, 'PROPULSAR', 3), (4, 19, 'PROPULSAR', 4),
 (4, 8, 'PAUSA', 5), (4, 7, 'PAUSA', 6), (4, 13, 'PANTALLA COMPLETA', 7),
 -- MENU PRINCIPAL
 (3, 2, 'SUBIR', 1), (3, 9, 'SUBIR', 2), (3, 3, 'BAJAR', 3), (3, 10, 'BAJAR', 4),
 (3, 6, 'ELEGIR', 5), (3, 1, 'ELEGIR', 6), (3, 16, 'ELEGIR', 7), (3, 7, 'IR A SALIR', 8),
 (3, 13, 'PANTALLA COMPLETA', 9),
 -- LOGIN
 (1, 2, 'SUBIR', 1), (1, 3, 'BAJAR', 2), (1, 6, 'ELEGIR', 3), (1, 16, 'ELEGIR', 4),
 (1, 7, 'SALIR DEL JUEGO', 5),
 -- REGISTRO
 (2, 14, 'ESCRIBIR', 1), (2, 12, 'BORRAR LETRA', 2), (2, 11, 'CAMBIAR CAMPO', 3),
 (2, 2, 'CAMPO ANTERIOR', 4), (2, 3, 'CAMPO SIGUIENTE', 5), (2, 6, 'SIGUIENTE/CREAR', 6),
 (2, 16, 'ELEGIR CAMPO', 7), (2, 7, 'CANCELAR', 8),
 -- PAUSA
 (5, 8, 'CONTINUAR', 1), (5, 7, 'CONTINUAR', 2), (5, 2, 'SUBIR', 3), (5, 3, 'BAJAR', 4),
 (5, 6, 'ELEGIR', 5), (5, 16, 'ELEGIR', 6),
 -- FIN
 (6, 1, 'REINTENTAR', 1), (6, 6, 'ELEGIR', 2), (6, 2, 'SUBIR', 3), (6, 3, 'BAJAR', 4),
 (6, 16, 'ELEGIR', 5), (6, 7, 'MENU', 6),
 -- LEADERBOARD
 (7, 4, 'ANTERIOR', 1), (7, 5, 'SIGUIENTE', 2), (7, 16, 'SIGUIENTE', 3),
 (7, 7, 'VOLVER', 4), (7, 6, 'VOLVER', 5),
 -- ESTADISTICAS
 (8, 4, 'ANTERIOR', 1), (8, 5, 'SIGUIENTE', 2), (8, 16, 'SIGUIENTE', 3),
 (8, 7, 'VOLVER', 4), (8, 6, 'VOLVER', 5),
 -- AJUSTES
 (9, 2, 'SUBIR', 1), (9, 3, 'BAJAR', 2), (9, 4, 'BAJAR VALOR', 3), (9, 5, 'SUBIR VALOR', 4),
 (9, 6, 'CAMBIAR/VOLVER', 5), (9, 16, 'CAMBIAR', 6), (9, 7, 'VOLVER', 7),
 -- CONTROLES
 (10, 4, 'ANTERIOR', 1), (10, 5, 'SIGUIENTE', 2), (10, 7, 'VOLVER', 3),
 (10, 6, 'VOLVER', 4),
 -- CREDITOS
 (11, 7, 'VOLVER', 1), (11, 6, 'VOLVER', 2), (11, 16, 'VOLVER', 3);
