"""
RASTREADOR: cuenta cada clic, toque y tecla (tabla EVENTO) y cada visita a una
pantalla (tabla USUARIO_MENU). Lo que pasa antes de elegir jugador (pantallas
LOGIN y REGISTRO) se guarda en espera y se asigna a la sesion cuando se inicia.
"""
import time

import pygame

from .bd import ahora


class Rastreador:
    def __init__(self, bd):
        self.bd = bd
        self.uid = None            # usuario y sesion actuales
        self.sesion = None
        self.num = 0               # contador de eventos de la sesion (discriminador)
        self.t0 = time.time()      # inicio de la sesion
        self.pendientes = []       # eventos sin guardar
        self.visitas = []          # visitas sin guardar (clave, segundos)
        self.menu = None           # pantalla actual
        self.menu_t = time.time()

    # ---------------------------------------------------------- sesion
    def iniciar(self, uid, num_sesion):
        self.uid, self.sesion, self.num = uid, num_sesion, 0
        self.guardar()             # lo que estaba en espera ya tiene dueno (se numera aqui)

    def terminar(self):
        self.salir_menu()
        self.guardar()
        if self.uid is not None:
            self.bd.cerrar_sesion(self.uid, self.sesion)
        self.uid = self.sesion = None
        self.t0 = time.time()

    # ---------------------------------------------------------- pantallas (menus)
    def entrar_menu(self, clave):
        if clave != self.menu:
            self.salir_menu()
            self.menu, self.menu_t = clave, time.time()
            self.guardar()

    def salir_menu(self):
        if self.menu:
            self.visitas.append((self.menu, time.time() - self.menu_t))
            self.menu = None

    # ---------------------------------------------------------- eventos
    def tecla_de(self, e):
        """id de la tabla TECLA que corresponde a un evento de pygame (o None si no cuenta)."""
        t = self.bd.teclas
        if e.type == pygame.KEYDOWN:
            if e.key == pygame.K_KP_ENTER:
                return t["K_RETURN"]
            for codigo, idt in t.items():
                if codigo.startswith("K_") and getattr(pygame, codigo) == e.key:
                    return idt
            return t["TEXTO"] if e.unicode and e.unicode.isalnum() else t["OTRA"]
        if e.type == pygame.MOUSEBUTTONDOWN and e.button in (1, 2, 3) and not getattr(e, "touch", False):
            return t["BOTON_%d" % e.button]
        if e.type == pygame.FINGERDOWN:
            return t["FINGERDOWN"]
        return None

    def registrar(self, e, pos):
        idt = self.tecla_de(e)
        if idt is None or self.menu is None:
            return
        ms = int((time.time() - self.t0) * 1000)
        x, y = (int(pos[0]), int(pos[1])) if pos else (None, None)
        self.pendientes.append((idt, self.bd.menus[self.menu], ahora(), ms, x, y))
        if self.uid is not None and len(self.pendientes) >= 40:
            self.guardar()

    def guardar(self):
        """Escribe en la BD lo pendiente (solo si ya hay jugador)."""
        if self.uid is None:
            return
        if self.pendientes:
            filas = []
            for p in self.pendientes:
                self.num += 1                                 # num_evento: 1, 2, 3... por sesion
                filas.append((self.uid, self.sesion, self.num, *p))
            self.bd.guardar_eventos(filas)
            self.pendientes = []
        for clave, seg in self.visitas:
            self.bd.visitar_menu(self.uid, clave, seg)
        self.visitas = []
