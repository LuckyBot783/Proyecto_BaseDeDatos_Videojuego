"""
BASE DE DATOS (SQLite): toda la gestion de datos del juego esta en esta clase.
El esquema esta en esquema.sql y los catalogos en datos_iniciales.sql.
"""
import os
import random
import sqlite3
from datetime import datetime

CARPETA = os.path.dirname(os.path.abspath(__file__))


def ahora():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


class BaseDatos:
    def __init__(self, ruta):
        self.con = sqlite3.connect(ruta)
        self.con.execute("PRAGMA foreign_keys = ON")
        for archivo in ("esquema.sql", "datos_iniciales.sql"):
            with open(os.path.join(CARPETA, archivo), encoding="utf-8") as f:
                self.con.executescript(f.read())
        self.con.commit()
        # diccionarios de apoyo: clave de menu -> id   y   codigo de tecla -> id
        self.menus = dict(self.con.execute("SELECT clave, id_menu FROM MENU"))
        self.teclas = dict(self.con.execute("SELECT codigo, id_tecla FROM TECLA"))

    def uno(self, sql, *args):
        """Primer renglon de una consulta (o None)."""
        return self.con.execute(sql, args).fetchone()

    def todos(self, sql, *args):
        return self.con.execute(sql, args).fetchall()

    # ================================================== II.a  usuarios y sesiones
    def usuarios(self):
        return self.todos("SELECT id_usuario, alias FROM USUARIO ORDER BY ultimo_acceso DESC, alias")

    def alias_existe(self, alias):
        return self.uno("SELECT 1 FROM USUARIO WHERE alias = ?", alias) is not None

    def crear_usuario(self, alias, nombre, apellido):
        cur = self.con.execute(
            "INSERT INTO USUARIO (alias, nombre, apellido, fecha_registro) VALUES (?, ?, ?, ?)",
            (alias, nombre, apellido, ahora()))
        uid = cur.lastrowid
        self.con.execute("INSERT INTO AJUSTES (id_usuario) VALUES (?)", (uid,))
        self.con.commit()
        return uid

    def usuario(self, uid):
        return self.uno("SELECT id_usuario, alias, nombre, apellido FROM USUARIO WHERE id_usuario = ?", uid)

    def iniciar_sesion(self, uid, sistema, resolucion):
        """Crea la sesion (entidad debil): su numero es el siguiente para ESE usuario."""
        num = self.uno("SELECT IFNULL(MAX(num_sesion), 0) + 1 FROM SESION WHERE id_usuario = ?", uid)[0]
        self.con.execute("INSERT INTO SESION VALUES (?, ?, ?, NULL, ?, ?)",
                         (uid, num, ahora(), sistema, resolucion))
        self.con.execute("UPDATE USUARIO SET ultimo_acceso = ? WHERE id_usuario = ?", (ahora(), uid))
        self.con.commit()
        return num

    def cerrar_sesion(self, uid, num):
        self.con.execute("UPDATE SESION SET fin = ? WHERE id_usuario = ? AND num_sesion = ?",
                         (ahora(), uid, num))
        self.con.commit()

    # ================================================== II.c  eventos y menus
    def guardar_eventos(self, filas):
        """filas = (id_usuario, num_sesion, num_evento, id_tecla, id_menu, momento, ms, x, y)"""
        self.con.executemany("INSERT INTO EVENTO VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", filas)
        self.con.commit()

    def visitar_menu(self, uid, clave, segundos):
        """Suma una visita y el tiempo que se estuvo en la pantalla (relacion N:M USUARIO_MENU)."""
        self.con.execute(
            "INSERT INTO USUARIO_MENU VALUES (?, ?, 1, ?, ?) "
            "ON CONFLICT (id_usuario, id_menu) DO UPDATE SET veces = veces + 1, "
            "ultima_visita = excluded.ultima_visita, segundos = ROUND(segundos + excluded.segundos, 2)",
            (uid, self.menus[clave], ahora(), round(segundos, 2)))
        self.con.commit()

    def opciones(self, clave):
        """Opciones de un menu (atributo multivaluado MENU_OPCION), en orden."""
        return [r[0] for r in self.todos(
            "SELECT opcion FROM MENU_OPCION WHERE id_menu = ? ORDER BY posicion", self.menus[clave])]

    def controles(self):
        """Para la pantalla CONTROLES: [(nombre_menu, [(tecla, accion), ...]), ...]"""
        res = []
        for idm, nombre in self.todos("SELECT DISTINCT m.id_menu, m.nombre FROM MENU m "
                                      "JOIN MENU_TECLA mt ON mt.id_menu = m.id_menu ORDER BY "
                                      "CASE m.clave WHEN 'JUEGO' THEN 0 ELSE m.id_menu END"):
            res.append((nombre, self.todos(
                "SELECT t.nombre, mt.accion FROM MENU_TECLA mt JOIN TECLA t ON t.id_tecla = mt.id_tecla "
                "WHERE mt.id_menu = ? ORDER BY mt.orden", idm)))
        return res

    # ================================================== ajustes
    def ajustes(self, uid):
        r = self.uno("SELECT id_nave, volumen, volumen_musica, pantalla_completa, mostrar_fps FROM AJUSTES "
                     "WHERE id_usuario = ?", uid)
        return {"nave": r[0], "volumen": r[1], "musica": r[2], "pantalla": bool(r[3]), "fps": bool(r[4])}

    def guardar_ajustes(self, uid, a):
        self.con.execute("UPDATE AJUSTES SET id_nave = ?, volumen = ?, volumen_musica = ?, "
                         "pantalla_completa = ?, mostrar_fps = ? WHERE id_usuario = ?",
                         (a["nave"], a["volumen"], a["musica"], int(a["pantalla"]), int(a["fps"]), uid))
        self.con.commit()

    # ================================================== catalogos del juego
    def naves(self):
        return self.todos("SELECT id_nave, nombre, carpeta FROM NAVE ORDER BY id_nave")

    def sortear_partida(self, id_nave=None):
        """Elige escenario (al azar), tubo (segun la probabilidad de TUBO_ESCENARIO) y nave."""
        esc = random.choice(self.todos("SELECT id_escenario, decoracion FROM ESCENARIO"))
        tubos = self.todos("SELECT t.id_tubo, t.estilo, te.probabilidad, te.hueco FROM TUBO_ESCENARIO te "
                           "JOIN TUBO t ON t.id_tubo = te.id_tubo WHERE te.id_escenario = ?", esc[0])
        tubo = random.choices(tubos, weights=[t[2] for t in tubos])[0]
        if id_nave is None:
            nave = random.choice(self.naves())
        else:
            nave = self.uno("SELECT id_nave, nombre, carpeta FROM NAVE WHERE id_nave = ?", id_nave)
        return {"escenario": esc, "tubo": tubo, "nave": nave, "hueco": tubo[3]}

    # ================================================== II.b  partidas y desempeno
    def record(self, uid):
        return self.uno("SELECT IFNULL(MAX(puntos), 0) FROM PARTIDA WHERE id_usuario = ?", uid)[0]

    def medalla_para(self, puntos):
        """La medalla mas alta que alcanza un puntaje (o None)."""
        return self.uno("SELECT id_medalla, nombre FROM MEDALLA WHERE puntos_minimos <= ? "
                        "ORDER BY puntos_minimos DESC LIMIT 1", puntos)

    def guardar_partida(self, uid, num_sesion, sorteo, inicio, duracion, puntos, aleteos, causa):
        """Guarda la partida. VICTORIA = superar tu record anterior; si no, DERROTA."""
        record_anterior = self.record(uid)
        resultado = "VICTORIA" if puntos > record_anterior else "DERROTA"
        self.con.execute(
            "INSERT INTO PARTIDA (id_usuario, num_sesion, id_nave, id_escenario, id_tubo, inicio, "
            "duracion_seg, puntos, aleteos, resultado, causa_fin) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (uid, num_sesion, sorteo["nave"][0], sorteo["escenario"][0], sorteo["tubo"][0], inicio,
             round(duracion, 2), puntos, aleteos, resultado, causa))
        medalla = self.medalla_para(puntos)
        if medalla:
            self.con.execute(
                "INSERT INTO USUARIO_MEDALLA VALUES (?, ?, ?, 1) ON CONFLICT (id_usuario, id_medalla) "
                "DO UPDATE SET veces = veces + 1", (uid, medalla[0], ahora()))
        self.con.commit()
        return {"resultado": resultado, "record_anterior": record_anterior, "medalla": medalla}

    def top_partidas(self, n=10):
        return self.todos(
            "SELECT p.id_partida, u.alias, p.puntos, p.inicio, u.id_usuario, n.nombre FROM PARTIDA p "
            "JOIN USUARIO u ON u.id_usuario = p.id_usuario JOIN NAVE n ON n.id_nave = p.id_nave "
            "ORDER BY p.puntos DESC, p.duracion_seg ASC, p.id_partida ASC LIMIT ?", n)

    def top_jugadores(self, n=10):
        return self.todos(
            "SELECT id_usuario, alias, record, partidas, puntos_acumulados FROM V_ESTADISTICAS "
            "WHERE partidas > 0 ORDER BY record DESC, puntos_acumulados DESC LIMIT ?", n)

    # ================================================== estadisticas (vista V_ESTADISTICAS)
    COLS = ("id_usuario", "alias", "nombre_completo", "partidas", "tiempo_juego_seg", "puntos_acumulados",
            "record", "victorias", "derrotas", "clics", "teclas", "interacciones_menu", "menus_abiertos")

    def estadisticas(self, uid):
        r = self.uno("SELECT %s FROM V_ESTADISTICAS WHERE id_usuario = ?" % ", ".join(self.COLS), uid)
        d = dict(zip(self.COLS, r))
        d["relacion"] = round(d["victorias"] / d["derrotas"], 2) if d["derrotas"] else float(d["victorias"])
        d["tiempo_sesiones"] = self.uno(
            "SELECT IFNULL(SUM((julianday(IFNULL(fin, ?)) - julianday(inicio)) * 86400), 0) "
            "FROM SESION WHERE id_usuario = ?", ahora(), uid)[0]
        return d

    def estadisticas_todos(self):
        return self.todos("SELECT alias, partidas, puntos_acumulados, victorias, derrotas FROM V_ESTADISTICAS "
                          "ORDER BY puntos_acumulados DESC, alias")

    def medallas_usuario(self, uid):
        return self.todos(
            "SELECT m.nombre, m.puntos_minimos, m.archivo, um.veces, um.fecha_obtencion FROM MEDALLA m "
            "LEFT JOIN USUARIO_MEDALLA um ON um.id_medalla = m.id_medalla AND um.id_usuario = ? "
            "ORDER BY m.puntos_minimos", uid)

    def cerrar(self):
        self.con.close()
