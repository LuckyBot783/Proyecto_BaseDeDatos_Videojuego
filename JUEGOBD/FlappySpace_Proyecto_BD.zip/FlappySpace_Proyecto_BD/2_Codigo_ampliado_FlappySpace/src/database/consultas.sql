-- =====================================================================
--  FLAPPY SPACE - Consultas
--  Parte 1: las 5 consultas del Algebra Relacional (punto I.11 / I.12)
--  Parte 2: estadisticas del videojuego (seccion II)
-- =====================================================================

-- ---------------------------------------------------------------------
-- C1. Seleccion + proyeccion + reunion natural
--     Alias, puntos y fecha de las partidas que fueron VICTORIA.
--     AR: π alias, puntos, inicio ( σ resultado='VICTORIA' ( USUARIO ⋈ PARTIDA ) )
-- ---------------------------------------------------------------------
SELECT u.alias, p.puntos, p.inicio
FROM USUARIO u
JOIN PARTIDA p ON p.id_usuario = u.id_usuario
WHERE p.resultado = 'VICTORIA'
ORDER BY p.inicio;

-- ---------------------------------------------------------------------
-- C2. Agrupacion y funciones de agregado
--     Por jugador: partidas jugadas, puntos acumulados y record.
--     AR: γ id_usuario, alias ; COUNT(id_partida)→partidas, SUM(puntos)→puntos,
--         MAX(puntos)→record ( USUARIO ⋈ PARTIDA )
-- ---------------------------------------------------------------------
SELECT u.id_usuario, u.alias,
       COUNT(p.id_partida) AS partidas,
       SUM(p.puntos)       AS puntos,
       MAX(p.puntos)       AS record
FROM USUARIO u
JOIN PARTIDA p ON p.id_usuario = u.id_usuario
GROUP BY u.id_usuario, u.alias
ORDER BY record DESC;

-- ---------------------------------------------------------------------
-- C3. Diferencia de conjuntos
--     Jugadores que NUNCA han abierto la pantalla de CREDITOS.
--     AR: π id_usuario, alias (USUARIO)
--         − π id_usuario, alias ( σ clave='CREDITOS' ( USUARIO ⋈ USUARIO_MENU ⋈ MENU ) )
-- ---------------------------------------------------------------------
SELECT id_usuario, alias FROM USUARIO
EXCEPT
SELECT u.id_usuario, u.alias
FROM USUARIO u
JOIN USUARIO_MENU um ON um.id_usuario = u.id_usuario
JOIN MENU m          ON m.id_menu     = um.id_menu
WHERE m.clave = 'CREDITOS';

-- ---------------------------------------------------------------------
-- C4. Division
--     Jugadores que ya jugaron en TODOS los escenarios.
--     AR: ( π id_usuario, id_escenario (PARTIDA) ÷ π id_escenario (ESCENARIO) ) ⋈ USUARIO
--     (en SQL: no existe un escenario en el que NO haya jugado)
-- ---------------------------------------------------------------------
SELECT u.id_usuario, u.alias
FROM USUARIO u
WHERE NOT EXISTS (
    SELECT 1 FROM ESCENARIO es
    WHERE NOT EXISTS (
        SELECT 1 FROM PARTIDA p
        WHERE p.id_usuario = u.id_usuario AND p.id_escenario = es.id_escenario));

-- ---------------------------------------------------------------------
-- C5. Reunion theta (condicion distinta de la igualdad)
--     Partidas que alcanzaron la medalla de ORO (30 puntos o mas).
--     AR: π id_partida, alias, puntos ( σ M.nombre='ORO'
--         ( (USUARIO ⋈ PARTIDA) ⋈ P.puntos >= M.puntos_minimos MEDALLA ) )
-- ---------------------------------------------------------------------
SELECT p.id_partida, u.alias, p.puntos
FROM USUARIO u
JOIN PARTIDA p ON p.id_usuario = u.id_usuario
JOIN MEDALLA m ON p.puntos >= m.puntos_minimos
WHERE m.nombre = 'ORO'
ORDER BY p.puntos DESC;


-- =====================================================================
--  II.a  Estadisticas del progreso del videojuego
-- =====================================================================
-- 1 y 2. Nombre e id de los usuarios
SELECT id_usuario, alias, nombre || ' ' || apellido AS nombre_completo, fecha_registro
FROM USUARIO ORDER BY id_usuario;

-- 3. Numero de partidas jugadas
SELECT u.id_usuario, u.alias, COUNT(p.id_partida) AS partidas_jugadas
FROM USUARIO u LEFT JOIN PARTIDA p ON p.id_usuario = u.id_usuario
GROUP BY u.id_usuario ORDER BY partidas_jugadas DESC;

-- 4. Tiempo total de juego (suma de las partidas) y tiempo total en sesiones
SELECT u.id_usuario, u.alias,
       IFNULL(ROUND(SUM(p.duracion_seg), 1), 0) AS segundos_jugando,
       (SELECT ROUND(SUM((julianday(s.fin) - julianday(s.inicio)) * 86400), 0)
          FROM SESION s WHERE s.id_usuario = u.id_usuario) AS segundos_en_sesiones
FROM USUARIO u LEFT JOIN PARTIDA p ON p.id_usuario = u.id_usuario
GROUP BY u.id_usuario;

-- =====================================================================
--  II.b  Estadisticas del desempeno del jugador
-- =====================================================================
-- 1 a 4. Puntos acumulados, victorias, derrotas y relacion victorias/derrotas
SELECT u.alias,
       IFNULL(SUM(p.puntos), 0)                                AS puntos_acumulados,
       SUM(CASE WHEN p.resultado = 'VICTORIA' THEN 1 ELSE 0 END) AS victorias,
       SUM(CASE WHEN p.resultado = 'DERROTA'  THEN 1 ELSE 0 END) AS derrotas,
       ROUND(1.0 * SUM(CASE WHEN p.resultado = 'VICTORIA' THEN 1 ELSE 0 END)
             / NULLIF(SUM(CASE WHEN p.resultado = 'DERROTA' THEN 1 ELSE 0 END), 0), 2) AS relacion_v_d
FROM USUARIO u LEFT JOIN PARTIDA p ON p.id_usuario = u.id_usuario
GROUP BY u.id_usuario ORDER BY puntos_acumulados DESC;

-- =====================================================================
--  II.c  Estadisticas de comportamiento e interaccion
-- =====================================================================
-- 1. Numero de clics del raton o toques en pantalla
SELECT u.alias, COUNT(e.num_evento) AS clics_y_toques
FROM USUARIO u
LEFT JOIN EVENTO e ON e.id_usuario = u.id_usuario
     AND e.id_tecla IN (SELECT id_tecla FROM TECLA WHERE dispositivo IN ('RATON', 'TACTIL'))
GROUP BY u.id_usuario;

-- 2. Numero de comandos del teclado (y cuales teclas se usan mas)
SELECT u.alias, COUNT(e.num_evento) AS comandos_teclado
FROM USUARIO u
LEFT JOIN EVENTO e ON e.id_usuario = u.id_usuario
     AND e.id_tecla IN (SELECT id_tecla FROM TECLA WHERE dispositivo = 'TECLADO')
GROUP BY u.id_usuario;

SELECT t.nombre AS tecla, t.dispositivo, COUNT(*) AS veces
FROM EVENTO e JOIN TECLA t ON t.id_tecla = e.id_tecla
GROUP BY t.id_tecla ORDER BY veces DESC;

-- 3. Numero de interacciones con los menus (acciones dentro de pantallas que no son el juego)
SELECT u.alias, m.nombre AS menu, COUNT(e.num_evento) AS interacciones
FROM EVENTO e
JOIN USUARIO u ON u.id_usuario = e.id_usuario
JOIN MENU m    ON m.id_menu    = e.id_menu
WHERE m.clave <> 'JUEGO'
GROUP BY u.id_usuario, m.id_menu ORDER BY u.alias, interacciones DESC;

-- ... y cuantas veces abrio cada menu y cuanto tiempo estuvo ahi
SELECT u.alias, m.nombre AS menu, um.veces, um.segundos, um.ultima_visita
FROM USUARIO_MENU um
JOIN USUARIO u ON u.id_usuario = um.id_usuario
JOIN MENU m    ON m.id_menu    = um.id_menu
ORDER BY u.alias, um.veces DESC;

-- Todo junto (vista creada en esquema.sql)
SELECT * FROM V_ESTADISTICAS;
