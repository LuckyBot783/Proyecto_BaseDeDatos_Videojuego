-- =====================================================================
--  FLAPPY SPACE - Esquema de la base de datos (SQLite)
--  Modelo Relacional obtenido del MER (notacion de Chen), en 4FN.
--  11 entidades (USUARIO, AJUSTES, SESION, PARTIDA, EVENTO, NAVE,
--  ESCENARIO, TUBO, MEDALLA, MENU, TECLA)
--  + 2 tablas de atributos multivaluados (NAVE_COLOR, MENU_OPCION)
--  + 4 tablas de interrelaciones N:M con atributos (USUARIO_MEDALLA,
--    USUARIO_MENU, MENU_TECLA, TUBO_ESCENARIO)
-- =====================================================================
PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------- catalogos
CREATE TABLE IF NOT EXISTS NAVE (
    id_nave      INTEGER PRIMARY KEY,
    nombre       VARCHAR(20)  NOT NULL UNIQUE,
    carpeta      VARCHAR(40)  NOT NULL,          -- carpeta de sus sprites en assets/naves
    descripcion  VARCHAR(80)  NOT NULL
);

-- atributo multivaluado "colores" de NAVE
CREATE TABLE IF NOT EXISTS NAVE_COLOR (
    id_nave      INTEGER     NOT NULL REFERENCES NAVE(id_nave) ON DELETE CASCADE,
    color_hex    CHAR(7)     NOT NULL,
    PRIMARY KEY (id_nave, color_hex)
);

CREATE TABLE IF NOT EXISTS ESCENARIO (
    id_escenario INTEGER PRIMARY KEY,
    nombre       VARCHAR(20)  NOT NULL UNIQUE,
    decoracion   VARCHAR(40)  NOT NULL,          -- imagen que adorna el fondo
    color_fondo  CHAR(7)      NOT NULL,
    descripcion  VARCHAR(80)  NOT NULL
);

CREATE TABLE IF NOT EXISTS TUBO (
    id_tubo      INTEGER PRIMARY KEY,
    nombre       VARCHAR(20)  NOT NULL UNIQUE,
    estilo       VARCHAR(40)  NOT NULL,          -- prefijo de los PNG (tech, neon, oxido)
    color_hex    CHAR(7)      NOT NULL,
    descripcion  VARCHAR(80)  NOT NULL
);

-- N:M  TUBO <aparece_en> ESCENARIO  (atributos: probabilidad, hueco)
CREATE TABLE IF NOT EXISTS TUBO_ESCENARIO (
    id_tubo      INTEGER      NOT NULL REFERENCES TUBO(id_tubo),
    id_escenario INTEGER      NOT NULL REFERENCES ESCENARIO(id_escenario),
    probabilidad DECIMAL(3,2) NOT NULL CHECK (probabilidad BETWEEN 0 AND 1),
    hueco        INTEGER      NOT NULL CHECK (hueco > 0),   -- espacio entre tubos (px)
    PRIMARY KEY (id_tubo, id_escenario)
);

CREATE TABLE IF NOT EXISTS MEDALLA (
    id_medalla     INTEGER PRIMARY KEY,
    nombre         VARCHAR(20) NOT NULL UNIQUE,
    puntos_minimos INTEGER     NOT NULL UNIQUE,
    archivo        VARCHAR(40) NOT NULL,
    descripcion    VARCHAR(80) NOT NULL
);

CREATE TABLE IF NOT EXISTS MENU (
    id_menu      INTEGER PRIMARY KEY,
    clave        VARCHAR(20) NOT NULL UNIQUE,
    nombre       VARCHAR(30) NOT NULL,
    descripcion  VARCHAR(80) NOT NULL
);

-- atributo multivaluado "opciones" de MENU
CREATE TABLE IF NOT EXISTS MENU_OPCION (
    id_menu      INTEGER     NOT NULL REFERENCES MENU(id_menu) ON DELETE CASCADE,
    opcion       VARCHAR(30) NOT NULL,
    posicion     INTEGER     NOT NULL,
    PRIMARY KEY (id_menu, opcion)
);

CREATE TABLE IF NOT EXISTS TECLA (
    id_tecla     INTEGER PRIMARY KEY,
    nombre       VARCHAR(20) NOT NULL UNIQUE,
    codigo       VARCHAR(20) NOT NULL,           -- nombre de la constante de pygame
    dispositivo  VARCHAR(10) NOT NULL CHECK (dispositivo IN ('TECLADO', 'RATON', 'TACTIL')),
    descripcion  VARCHAR(80) NOT NULL
);

-- N:M  MENU <asigna> TECLA  (atributos: accion, orden)
CREATE TABLE IF NOT EXISTS MENU_TECLA (
    id_menu      INTEGER     NOT NULL REFERENCES MENU(id_menu),
    id_tecla     INTEGER     NOT NULL REFERENCES TECLA(id_tecla),
    accion       VARCHAR(30) NOT NULL,
    orden        INTEGER     NOT NULL,
    PRIMARY KEY (id_menu, id_tecla)
);

-- ---------------------------------------------------------- jugadores
CREATE TABLE IF NOT EXISTS USUARIO (
    id_usuario     INTEGER PRIMARY KEY AUTOINCREMENT,
    alias          VARCHAR(8)  NOT NULL UNIQUE,
    nombre         VARCHAR(12) NOT NULL,         -- nombre_completo.nombre
    apellido       VARCHAR(12) NOT NULL,         -- nombre_completo.apellido
    fecha_registro DATETIME    NOT NULL,
    ultimo_acceso  DATETIME
);

-- 1:1  USUARIO <configura> AJUSTES   y   N:1  AJUSTES <prefiere> NAVE
CREATE TABLE IF NOT EXISTS AJUSTES (
    id_ajustes        INTEGER PRIMARY KEY AUTOINCREMENT,
    id_usuario        INTEGER NOT NULL UNIQUE REFERENCES USUARIO(id_usuario) ON DELETE CASCADE,
    id_nave           INTEGER REFERENCES NAVE(id_nave),          -- NULL = aleatoria
    volumen           INTEGER NOT NULL DEFAULT 80 CHECK (volumen BETWEEN 0 AND 100),
    volumen_musica    INTEGER NOT NULL DEFAULT 60 CHECK (volumen_musica BETWEEN 0 AND 100),
    pantalla_completa BOOLEAN NOT NULL DEFAULT 0,
    mostrar_fps       BOOLEAN NOT NULL DEFAULT 0
);

-- entidad DEBIL de USUARIO (relacion identificadora <inicia>)
CREATE TABLE IF NOT EXISTS SESION (
    id_usuario        INTEGER     NOT NULL REFERENCES USUARIO(id_usuario) ON DELETE CASCADE,
    num_sesion        INTEGER     NOT NULL,      -- discriminador
    inicio            DATETIME    NOT NULL,
    fin               DATETIME,
    sistema_operativo VARCHAR(20) NOT NULL,      -- equipo.sistema_operativo
    resolucion        VARCHAR(12) NOT NULL,      -- equipo.resolucion
    PRIMARY KEY (id_usuario, num_sesion)
);

-- 1:N  SESION <contiene> PARTIDA ; N:1 con NAVE, ESCENARIO y TUBO
CREATE TABLE IF NOT EXISTS PARTIDA (
    id_partida   INTEGER PRIMARY KEY AUTOINCREMENT,
    id_usuario   INTEGER     NOT NULL,
    num_sesion   INTEGER     NOT NULL,
    id_nave      INTEGER     NOT NULL REFERENCES NAVE(id_nave),
    id_escenario INTEGER     NOT NULL REFERENCES ESCENARIO(id_escenario),
    id_tubo      INTEGER     NOT NULL REFERENCES TUBO(id_tubo),
    inicio       DATETIME    NOT NULL,
    duracion_seg DECIMAL(8,2) NOT NULL,
    puntos       INTEGER     NOT NULL CHECK (puntos >= 0),
    aleteos      INTEGER     NOT NULL CHECK (aleteos >= 0),
    resultado    VARCHAR(8)  NOT NULL CHECK (resultado IN ('VICTORIA', 'DERROTA')),
    causa_fin    VARCHAR(8)  NOT NULL CHECK (causa_fin IN ('TUBO', 'PISO', 'ABANDONO')),
    FOREIGN KEY (id_usuario, num_sesion) REFERENCES SESION(id_usuario, num_sesion) ON DELETE CASCADE
);

-- entidad DEBIL de SESION (relacion identificadora <registra>)
-- N:1 EVENTO <corresponde_a> TECLA  y  N:1 EVENTO <ocurre_en> MENU
CREATE TABLE IF NOT EXISTS EVENTO (
    id_usuario   INTEGER  NOT NULL,
    num_sesion   INTEGER  NOT NULL,
    num_evento   INTEGER  NOT NULL,              -- discriminador
    id_tecla     INTEGER  NOT NULL REFERENCES TECLA(id_tecla),
    id_menu      INTEGER  NOT NULL REFERENCES MENU(id_menu),
    momento      DATETIME NOT NULL,
    ms_sesion    INTEGER  NOT NULL,              -- milisegundos desde que inicio la sesion
    pos_x        INTEGER,                        -- posicion.x (en pixeles del juego)
    pos_y        INTEGER,                        -- posicion.y
    PRIMARY KEY (id_usuario, num_sesion, num_evento),
    FOREIGN KEY (id_usuario, num_sesion) REFERENCES SESION(id_usuario, num_sesion) ON DELETE CASCADE
);

-- N:M  USUARIO <obtiene> MEDALLA  (atributos: fecha_obtencion, veces)
CREATE TABLE IF NOT EXISTS USUARIO_MEDALLA (
    id_usuario      INTEGER  NOT NULL REFERENCES USUARIO(id_usuario) ON DELETE CASCADE,
    id_medalla      INTEGER  NOT NULL REFERENCES MEDALLA(id_medalla),
    fecha_obtencion DATETIME NOT NULL,
    veces           INTEGER  NOT NULL DEFAULT 1,
    PRIMARY KEY (id_usuario, id_medalla)
);

-- N:M  USUARIO <visita> MENU  (atributos: veces, ultima_visita, segundos)
CREATE TABLE IF NOT EXISTS USUARIO_MENU (
    id_usuario    INTEGER      NOT NULL REFERENCES USUARIO(id_usuario) ON DELETE CASCADE,
    id_menu       INTEGER      NOT NULL REFERENCES MENU(id_menu),
    veces         INTEGER      NOT NULL DEFAULT 0,
    ultima_visita DATETIME     NOT NULL,
    segundos      DECIMAL(10,2) NOT NULL DEFAULT 0,
    PRIMARY KEY (id_usuario, id_menu)
);

CREATE INDEX IF NOT EXISTS idx_partida_usuario ON PARTIDA(id_usuario, puntos DESC);
CREATE INDEX IF NOT EXISTS idx_evento_tecla    ON EVENTO(id_tecla);

-- ---------------------------------------------------------- vista con TODAS las estadisticas
DROP VIEW IF EXISTS V_ESTADISTICAS;
CREATE VIEW V_ESTADISTICAS AS
SELECT u.id_usuario,
       u.alias,
       u.nombre || ' ' || u.apellido                                   AS nombre_completo,
       (SELECT COUNT(*) FROM PARTIDA p WHERE p.id_usuario = u.id_usuario) AS partidas,
       (SELECT IFNULL(ROUND(SUM(p.duracion_seg), 1), 0)
          FROM PARTIDA p WHERE p.id_usuario = u.id_usuario)            AS tiempo_juego_seg,
       (SELECT IFNULL(SUM(p.puntos), 0)
          FROM PARTIDA p WHERE p.id_usuario = u.id_usuario)            AS puntos_acumulados,
       (SELECT IFNULL(MAX(p.puntos), 0)
          FROM PARTIDA p WHERE p.id_usuario = u.id_usuario)            AS record,
       (SELECT COUNT(*) FROM PARTIDA p
         WHERE p.id_usuario = u.id_usuario AND p.resultado = 'VICTORIA') AS victorias,
       (SELECT COUNT(*) FROM PARTIDA p
         WHERE p.id_usuario = u.id_usuario AND p.resultado = 'DERROTA')  AS derrotas,
       (SELECT COUNT(*) FROM EVENTO e JOIN TECLA t ON t.id_tecla = e.id_tecla
         WHERE e.id_usuario = u.id_usuario AND t.dispositivo IN ('RATON', 'TACTIL')) AS clics,
       (SELECT COUNT(*) FROM EVENTO e JOIN TECLA t ON t.id_tecla = e.id_tecla
         WHERE e.id_usuario = u.id_usuario AND t.dispositivo = 'TECLADO') AS teclas,
       (SELECT COUNT(*) FROM EVENTO e JOIN MENU m ON m.id_menu = e.id_menu
         WHERE e.id_usuario = u.id_usuario AND m.clave <> 'JUEGO')       AS interacciones_menu,
       (SELECT IFNULL(SUM(um.veces), 0) FROM USUARIO_MENU um
         WHERE um.id_usuario = u.id_usuario)                            AS menus_abiertos
FROM USUARIO u;
