import asyncio
import platform
import sys

import pygame
from pygame.locals import K_ESCAPE, K_SPACE, K_UP, KEYDOWN, QUIT

from .database import BaseDatos, Rastreador, ahora
from .entities import (
    Background,
    Floor,
    GameOver,
    Pipes,
    Player,
    PlayerMode,
    Score,
    WelcomeMessage,
)
from .screens import AjustesPantalla, Comun, Lista, LoginPantalla, MenuPantalla, TablasPantalla
from .utils import Fuente, GameConfig, Images, Sounds, Window
from .utils.constants import ALTO, ANCHO, BLUE, CYAN, FPS, GOLD, LIME, MAG, NAVY, TITULO, UI, WHITE

MEDALLA_IMG = {1: "bronce", 2: "plata", 3: "oro", 4: "platino"}


class Flappy(Comun, LoginPantalla, MenuPantalla, TablasPantalla, AjustesPantalla):
    def __init__(self, ruta_bd="flappy_space_bd.db"):
        pygame.init()
        pygame.display.set_caption(TITULO)
        window = Window(ANCHO, ALTO)              # abre la ventana escalada
        images = Images()
        pygame.display.set_icon(pygame.image.load(UI + "icono.png"))

        self.config = GameConfig(
            screen=pygame.Surface((ANCHO, ALTO)),  # lienzo chico de pixel art
            clock=pygame.time.Clock(),
            fps=FPS,
            window=window,
            images=images,
            sounds=Sounds(),
        )
        # NUEVO: base de datos, rastreo de eventos y datos del jugador
        self.fuente = Fuente(images.fuente)
        self.bd = BaseDatos(ruta_bd)
        self.rastreo = Rastreador(self.bd)
        self.uid = None
        self.sesion = None
        self.ajustes = {"nave": None, "volumen": 80, "musica": 60, "pantalla": False, "fps": False}
        self.mouse = (0, 0)
        self.t = 0                                 # cuadros desde que abrio el juego
        self.en_partida = False
        self.background = Background(self.config)
        self.floor = Floor(self.config)

    async def start(self):
        """NUEVO: login -> menu principal -> la opcion que se elija."""
        await self.login()
        while True:
            op = await self.menu_principal()
            if op == "JUGAR":
                await self.jugar()
            elif op == "LEADERBOARD":
                await self.leaderboard()
            elif op == "ESTADISTICAS":
                await self.estadisticas()
            elif op == "AJUSTES":
                await self.menu_ajustes()
            elif op == "CONTROLES":
                await self.controles()
            elif op == "CREDITOS":
                await self.creditos()
            elif op == "OTRO JUGADOR":
                self.cerrar_sesion()
                await self.login()
            elif op == "SALIR":
                self.salir()

    # ================================================================ sesion
    def iniciar_sesion(self, uid):
        w = self.config.window.display.get_size()
        self.uid = uid
        self.sesion = self.bd.iniciar_sesion(uid, platform.system()[:20], "%dx%d" % w)
        self.rastreo.iniciar(uid, self.sesion)
        self.ajustes = self.bd.ajustes(uid)
        self.aplicar_ajustes()

    def cerrar_sesion(self):
        self.rastreo.terminar()
        self.uid = self.sesion = None

    def salir(self):
        if self.en_partida:                        # cerrar a media partida cuenta como abandono
            self.guardar_partida("ABANDONO")
        self.cerrar_sesion()
        self.bd.cerrar()
        pygame.quit()
        sys.exit()

    # ================================================================ bucle comun
    def eventos(self):
        """Lee los eventos de pygame y los manda al rastreador (clics, toques y teclas)."""
        lista = []
        for e in pygame.event.get():
            if e.type == QUIT:
                self.salir()
            if hasattr(e, "pos"):
                self.mouse = self.config.window.a_lienzo(e.pos)
            elif e.type == pygame.FINGERDOWN:
                w = self.config.window
                dw, dh = w.display.get_size()
                self.mouse = w.a_lienzo((e.x * dw, e.y * dh))
            if e.type == KEYDOWN and e.key == pygame.K_F11:
                self.ajustes["pantalla"] = not self.ajustes["pantalla"]
                self.aplicar_ajustes()
                if self.uid:
                    self.bd.guardar_ajustes(self.uid, self.ajustes)
            self.rastreo.registrar(e, self.mouse)
            lista.append(e)
        return lista

    async def cuadro(self):
        """Termina un cuadro: FPS (si se pidio), escala a la ventana y espera."""
        self.t += 1
        if self.ajustes["fps"]:
            self.texto("%d FPS" % round(self.config.clock.get_fps()), 2, 2, WHITE, sombra=NAVY)
        self.config.tick()
        await asyncio.sleep(0)

    async def pantalla(self, clave, manejar, dibujar):
        """Bucle de cualquier menu: cuenta la visita (USUARIO_MENU) y repite hasta tener respuesta."""
        self.rastreo.entrar_menu(clave)
        while True:
            for e in self.eventos():
                r = manejar(e)
                if r is not None:
                    return r
            dibujar()
            await self.cuadro()

    def is_tap_event(self, event):
        """Antes usaba pygame.mouse.get_pressed() y contaba de mas; ahora solo el evento."""
        space_or_up = event.type == KEYDOWN and (event.key == K_SPACE or event.key == K_UP)
        clic = (event.type == pygame.MOUSEBUTTONDOWN and event.button == 1
                and not getattr(event, "touch", False))
        screen_tap = event.type == pygame.FINGERDOWN
        return clic or space_or_up or screen_tap

    # ================================================================ la partida
    async def jugar(self):
        """Partidas seguidas hasta que se elija MENU (REINTENTAR vuelve a empezar)."""
        while True:
            self.sorteo = self.bd.sortear_partida(self.ajustes["nave"])
            self.config.images.preparar(self.sorteo)
            self.background = Background(self.config)
            self.floor = Floor(self.config)
            self.player = Player(self.config)
            self.welcome_message = WelcomeMessage(self.config)
            self.game_over_message = GameOver(self.config)
            self.pipes = Pipes(self.config, self.sorteo["hueco"])
            self.score = Score(self.config)
            self.rastreo.entrar_menu("JUEGO")
            self.config.sounds.tocar("juego")
            await self.splash()
            causa = await self.play()
            resultado = self.guardar_partida(causa)
            if causa == "ABANDONO" or await self.game_over(resultado) == "MENU":
                self.floor.vel_x = Floor(self.config).vel_x
                self.background.vel = 1.0
                return

    async def splash(self):
        """Shows welcome splash screen animation of flappy bird"""

        self.player.set_mode(PlayerMode.SHM)

        while True:
            for event in self.eventos():
                if self.is_tap_event(event):
                    return

            self.background.tick()
            self.floor.tick()
            self.player.tick()
            self.welcome_message.tick()
            nombre = self.sorteo["nave"][1]
            self.texto("NAVE: %s" % nombre, ANCHO // 2, 42, GOLD, "c", NAVY)
            if (self.t // 20) % 2 == 0:
                self.texto("ESPACIO / CLIC: PROPULSAR", ANCHO // 2, 112, WHITE, "c", NAVY)
            self.texto("P / ESC: PAUSA", ANCHO // 2, 124, BLUE, "c", NAVY)
            await self.cuadro()

    async def play(self):
        self.score.reset()
        self.player.set_mode(PlayerMode.NORMAL)
        self.en_partida = True
        self.inicio_partida = ahora()
        self.cuadros = 0                               # duracion real (sin contar la pausa)

        while True:
            if self.player.collided(self.pipes, self.floor):
                self.en_partida = False
                return "TUBO" if self.player.crash_entity == "pipe" else "PISO"

            for i, pipe in enumerate(self.pipes.upper):
                if self.player.crossed(pipe):
                    self.score.add()

            for event in self.eventos():
                if self.is_tap_event(event):
                    self.player.flap()
                elif (event.type == KEYDOWN and event.key in (pygame.K_p, K_ESCAPE)) \
                        or event.type == pygame.WINDOWFOCUSLOST:
                    if await self.pausa() == "SALIR AL MENU":
                        self.en_partida = False
                        return "ABANDONO"
                    self.rastreo.entrar_menu("JUEGO")

            self.background.tick()
            self.floor.tick()
            self.pipes.tick()
            self.score.tick()
            self.player.tick()
            self.cuadros += 1
            await self.cuadro()

    def guardar_partida(self, causa):
        """NUEVO: guarda la partida en la base de datos (tabla PARTIDA)."""
        self.en_partida = False
        res = self.bd.guardar_partida(self.uid, self.sesion, self.sorteo, self.inicio_partida,
                                      self.cuadros / FPS, self.score.score, self.player.aleteos, causa)
        self.rastreo.guardar()
        return res

    async def pausa(self):
        """NUEVO: pausa con CONTINUAR / SALIR AL MENU."""
        foto = self.config.screen.copy()
        ops = self.bd.opciones("PAUSA")
        lista = Lista(ops, 78)

        def manejar(e):
            if e.type == KEYDOWN and e.key == pygame.K_p:
                return "CONTINUAR"
            r = lista.manejar(e, self.mouse, self.config.sounds)
            return "CONTINUAR" if r == "ATRAS" else None if r is None else ops[r]

        def dibujar():
            self.config.screen.blit(foto, (0, 0))
            self.oscurecer()
            img = self.config.images.pausa
            self.config.screen.blit(img, ((ANCHO - img.get_width()) // 2, 48))
            lista.dibujar(self, self.t)

        return await self.pantalla("PAUSA", manejar, dibujar)

    async def game_over(self, res):
        """crashes the player down and shows gameover image (+ NUEVO: panel de resultados)"""

        self.player.set_mode(PlayerMode.CRASH)
        self.pipes.stop()
        self.floor.stop()
        if res["resultado"] == "VICTORIA":
            self.config.sounds.record.play()
        ops = self.bd.opciones("FIN")
        lista = Lista(ops, 70, x=236)
        panel_y = [190]
        PY = 40
        img = self.config.images

        def en_piso():
            return self.player.y + self.player.h >= self.floor.y - 1

        def manejar(e):
            if not en_piso() or panel_y[0] > PY:
                return None
            if e.type == KEYDOWN and e.key == K_SPACE:
                return "REINTENTAR"
            r = lista.manejar(e, self.mouse, self.config.sounds)
            return "MENU" if r == "ATRAS" else None if r is None else ops[r]

        def dibujar():
            self.background.tick()
            self.floor.tick()
            self.pipes.tick()
            self.player.tick()
            self.game_over_message.tick()
            if not en_piso():
                return
            panel_y[0] = max(PY, panel_y[0] - 8)
            y = panel_y[0]
            px = 30
            self.config.screen.blit(img.panel, (px, y))
            gano = res["resultado"] == "VICTORIA"
            self.texto(res["resultado"], px + 64, y + 6, LIME if gano else MAG, "c")
            self.texto("PUNTOS", px + 10, y + 19, CYAN)
            self.texto(str(self.score.score), px + 118, y + 19, WHITE, "d")
            self.texto("RECORD", px + 10, y + 29, CYAN)
            self.texto(str(max(res["record_anterior"], self.score.score)), px + 118, y + 29, GOLD, "d")
            self.texto("ALETEOS", px + 10, y + 39, CYAN)
            self.texto(str(self.player.aleteos), px + 118, y + 39, WHITE, "d")
            self.texto("MEDALLA", px + 10, y + 61, CYAN)
            if res["medalla"]:
                self.config.screen.blit(img.medallas[MEDALLA_IMG[res["medalla"][0]]], (px + 102, y + 56))
                self.texto(res["medalla"][1], px + 98, y + 61, GOLD, "d")
            else:
                self.texto("NINGUNA", px + 118, y + 61, BLUE, "d")
            if gano and (self.t // 15) % 2 == 0:
                self.texto("NUEVO RECORD!", px + 64, y + 82, GOLD, "c")
            elif not gano:
                self.texto("SUPERA %d PARA GANAR" % res["record_anterior"], px + 64, y + 82, BLUE, "c")
            if panel_y[0] == PY:
                lista.dibujar(self, self.t)
                self.texto("ESPACIO: REINTENTAR", 236, 112, WHITE, "c", NAVY)

        self.rastreo.entrar_menu("FIN")
        return await self.pantalla("FIN", manejar, dibujar)
