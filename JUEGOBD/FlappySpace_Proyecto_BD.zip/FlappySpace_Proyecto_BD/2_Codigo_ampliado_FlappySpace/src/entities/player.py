from enum import Enum
from itertools import cycle

import pygame

from ..utils import GameConfig, clamp
from ..utils import get_hit_mask
from ..utils.constants import CHOQUE, FLOTAR, NORMAL
from .entity import Entity
from .floor import Floor
from .pipe import Pipe, Pipes


class PlayerMode(Enum):
    SHM = "SHM"
    NORMAL = "NORMAL"
    CRASH = "CRASH"


class Player(Entity):
    def __init__(self, config: GameConfig) -> None:
        image = config.images.player[0]
        x = int(config.window.width * 0.2)
        y = int((config.window.height - image.get_height()) / 2)
        super().__init__(config, image, x, y)
        self.min_y = -2 * self.h
        self.max_y = config.window.viewport_height - self.h * 0.75
        self.img_idx = 0
        self.img_gen = cycle([0, 1, 2, 1])
        self.frame = 0
        self.crashed = False
        self.crash_entity = None
        self.aleteos = 0              # NUEVO: cuantas veces aleteo en la partida
        self.set_mode(PlayerMode.SHM)

    def set_mode(self, mode: PlayerMode) -> None:
        self.mode = mode
        if mode == PlayerMode.NORMAL:
            self.reset_vals_normal()
            self.config.sounds.wing.play()
        elif mode == PlayerMode.SHM:
            self.reset_vals_shm()
        elif mode == PlayerMode.CRASH:
            self.stop_wings()
            self.config.sounds.hit.play()
            if self.crash_entity == "pipe":
                self.config.sounds.die.play()
            self.reset_vals_crash()

    def reset_vals_normal(self) -> None:
        self.vel_y = NORMAL["vel_y"]  # player's velocity along Y axis
        self.max_vel_y = NORMAL["max_vel_y"]  # max vel along Y, max descend speed
        self.min_vel_y = NORMAL["min_vel_y"]  # min vel along Y, max ascend speed
        self.acc_y = NORMAL["acc_y"]  # players downward acceleration

        self.rot = 0  # player's current rotation
        self.vel_rot = 0  # la nave no gira: cambia de pose (sube / normal / cae)
        self.rot_min = -90  # player's min rotation angle
        self.rot_max = 0  # player's max rotation angle

        self.flap_acc = NORMAL["vel_y"]  # players speed on flapping
        self.flapped = False  # True when player flaps

    def reset_vals_shm(self) -> None:
        self.vel_y = FLOTAR["vel_y"]  # player's velocity along Y axis
        self.max_vel_y = FLOTAR["max_vel_y"]  # max vel along Y, max descend speed
        self.min_vel_y = FLOTAR["min_vel_y"]  # min vel along Y, max ascend speed
        self.acc_y = FLOTAR["acc_y"]  # players downward acceleration

        self.rot = 0  # player's current rotation
        self.vel_rot = 0  # player's rotation speed
        self.rot_min = 0  # player's min rotation angle
        self.rot_max = 0  # player's max rotation angle

        self.flap_acc = 0  # players speed on flapping
        self.flapped = False  # True when player flaps

    def reset_vals_crash(self) -> None:
        self.acc_y = CHOQUE["acc_y"]
        self.vel_y = CHOQUE["vel_y"]
        self.max_vel_y = CHOQUE["max_vel_y"]
        self.vel_rot = CHOQUE["vel_rot"]

    def update_image(self):
        """Antes aleteaba en ciclo; la nave elige su pose segun su velocidad."""
        self.frame += 1
        if self.mode == PlayerMode.NORMAL:
            self.img_idx = 0 if self.vel_y < -0.8 else 2 if self.vel_y > 1.5 else 1
        elif self.mode == PlayerMode.SHM:
            self.img_idx = 1
        self.image = self.config.images.player[self.img_idx]
        self.hit_mask = get_hit_mask(self.image)

    def tick_shm(self) -> None:
        if self.vel_y >= self.max_vel_y or self.vel_y <= self.min_vel_y:
            self.acc_y *= -1
        self.vel_y += self.acc_y
        self.y += self.vel_y

    def tick_normal(self) -> None:
        if self.vel_y < self.max_vel_y and not self.flapped:
            self.vel_y += self.acc_y
        if self.flapped:
            self.flapped = False

        self.y = clamp(self.y + self.vel_y, self.min_y, self.max_y)
        self.rotate()

    def tick_crash(self) -> None:
        if self.min_y <= self.y <= self.max_y:
            self.y = clamp(self.y + self.vel_y, self.min_y, self.max_y)
            # rotate only when it's a pipe crash and bird is still falling
            if self.crash_entity != "floor":
                self.rotate()

        # player velocity change
        if self.vel_y < self.max_vel_y:
            self.vel_y += self.acc_y

    def rotate(self) -> None:
        self.rot = clamp(self.rot + self.vel_rot, self.rot_min, self.rot_max)

    def draw(self) -> None:
        self.update_image()
        if self.mode == PlayerMode.SHM:
            self.tick_shm()
        elif self.mode == PlayerMode.NORMAL:
            self.tick_normal()
        elif self.mode == PlayerMode.CRASH:
            self.tick_crash()

        self.draw_player()

    def draw_player(self) -> None:
        if self.mode != PlayerMode.CRASH:          # NUEVO: fuego del propulsor
            fuego = self.config.images.fuego[(self.frame // 4) % 2]
            self.config.screen.blit(fuego, (self.x - 2, self.y + self.h // 2 - 2))
        rotated_image = pygame.transform.rotate(self.image, int(self.rot) // 15 * 15)
        rotated_rect = rotated_image.get_rect(center=self.rect.center)
        self.config.screen.blit(rotated_image, rotated_rect)

    def stop_wings(self) -> None:
        self.img_gen = cycle([self.img_idx])

    def flap(self) -> None:
        if self.y > self.min_y:
            self.vel_y = self.flap_acc
            self.flapped = True
            self.aleteos += 1
            self.config.sounds.wing.play()

    def crossed(self, pipe: Pipe) -> bool:
        return pipe.cx <= self.cx < pipe.cx - pipe.vel_x

    def collided(self, pipes: Pipes, floor: Floor) -> bool:
        """returns True if player collides with floor or pipes."""

        # if player crashes into ground
        if self.collide(floor):
            self.crashed = True
            self.crash_entity = "floor"
            return True

        for pipe in pipes.upper:
            if self.collide(pipe):
                self.crashed = True
                self.crash_entity = "pipe"
                return True
        for pipe in pipes.lower:
            if self.collide(pipe):
                self.crashed = True
                self.crash_entity = "pipe"
                return True

        return False
