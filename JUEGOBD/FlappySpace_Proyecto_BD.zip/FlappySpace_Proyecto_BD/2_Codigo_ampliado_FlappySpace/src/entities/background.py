import math

from ..utils import GameConfig
from .entity import Entity


class Background(Entity):
    """Antes era una imagen fija. NUEVO: estrellas en 3 capas (parallax) y la decoracion
    del escenario que eligio la base de datos (planeta, asteroides o techo electrico)."""
    def __init__(self, config: GameConfig) -> None:
        super().__init__(config)
        self.w, self.h = config.window.width, config.window.height
        self.recorrido = 0.0
        self.vel = 1.0
        self.t = 0

    def draw(self) -> None:
        img, s = self.config.images, self.config.screen
        s.fill((7, 6, 20))
        self.recorrido += self.vel
        self.t += 1
        sd = int(self.recorrido)
        for capa, fac in zip(img.estrellas, (0.08, 0.22, 0.5)):
            off = int(sd * fac) % self.w
            s.blit(capa, (-off, 0))
            s.blit(capa, (self.w - off, 0))
        esc = img.escenario
        if esc == "planeta.png":
            s.blit(img.planeta, (int(250 - sd * 0.04) % (self.w + 70) - 40, 30))
        elif esc == "asteroide_1.png":
            for k in range(7):
                a = img.asteroides[k % 3]
                x = int(k * 53 - sd * (0.25 + k % 3 * 0.08)) % (self.w + 30) - 15
                s.blit(a, (x, 20 + (k * 37) % 110 + int(math.sin(self.t * 0.02 + k) * 2)))
        else:
            for k in range(14):
                if (self.t // 20 + k) % 4:
                    s.blit(img.brillo, ((k * 97 - int(sd * 0.5)) % self.w, 8 + (k * 41) % 140))
            techo = img.techo[(self.t // 6) % 2]
            for x in range(-(sd % 16), self.w, 16):
                s.blit(techo, (x, 0))
