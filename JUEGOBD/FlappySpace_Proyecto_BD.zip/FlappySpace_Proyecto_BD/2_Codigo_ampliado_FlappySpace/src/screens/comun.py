"""
COMUN: piezas que usan todas las pantallas (lista de botones, fondo, textos).
"""
import pygame
from pygame.locals import KEYDOWN, MOUSEBUTTONDOWN, MOUSEMOTION

from ..utils.constants import ALTO, ANCHO, BLUE, CYAN, NAVY, WHITE

ARRIBA = (pygame.K_UP, pygame.K_w)
ABAJO = (pygame.K_DOWN, pygame.K_s)
ACEPTAR = (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE)
BOTON_W, BOTON_H = 88, 16


class Lista:
    """Columna de botones que se elige con flechas/W/S + Enter/Espacio, o con el raton."""
    def __init__(self, opciones, y0, paso=18, x=ANCHO // 2, sel=0, visibles=99):
        self.opciones = list(opciones)
        self.y0, self.paso, self.x = y0, paso, x
        self.sel = sel
        self.visibles = visibles     # si hay mas opciones, la lista se desplaza
        self.ini = 0

    def rango(self):
        """Indices que se ven en pantalla (se recorre para que la seleccion siempre se vea)."""
        self.ini = min(max(self.ini, self.sel - self.visibles + 1), self.sel)
        return range(self.ini, min(len(self.opciones), self.ini + self.visibles))

    def rect(self, i):
        return pygame.Rect(self.x - BOTON_W // 2, self.y0 + (i - self.ini) * self.paso, BOTON_W, BOTON_H)

    def manejar(self, e, mouse, sonidos):
        """Devuelve el indice elegido, 'ATRAS' con ESC, o None."""
        n = len(self.opciones)
        if e.type == KEYDOWN:
            if e.key in ARRIBA or e.key in ABAJO:
                self.sel = (self.sel + (-1 if e.key in ARRIBA else 1)) % n
                sonidos.mover.play()
            elif e.key in ACEPTAR:
                sonidos.aceptar.play()
                return self.sel
            elif e.key == pygame.K_ESCAPE:
                return "ATRAS"
        elif e.type == MOUSEMOTION:
            for i in self.rango():
                if self.rect(i).collidepoint(mouse) and i != self.sel:
                    self.sel = i
                    sonidos.mover.play()
        elif e.type == MOUSEBUTTONDOWN and e.button == 1:
            for i in self.rango():
                if self.rect(i).collidepoint(mouse):
                    self.sel = i
                    sonidos.aceptar.play()
                    return i
        return None

    def dibujar(self, juego, t):
        for i in self.rango():
            op, r = self.opciones[i], self.rect(i)
            sel = i == self.sel
            dy = -1 if sel and (t // 20) % 2 else 0
            juego.boton(op, r.centerx, r.y + dy, sel)


class Comun:
    """Metodos de dibujo compartidos (Flappy hereda de esta clase)."""
    def texto(self, t, x, y, color=WHITE, alinear="i", sombra=None):
        return self.fuente.dibujar(self.config.screen, t, x, y, color, alinear, sombra)

    def boton(self, t, cx, y, sel=False):
        img = self.config.images.boton_sel if sel else self.config.images.boton
        self.config.screen.blit(img, (cx - img.get_width() // 2, y))
        self.texto(t, cx, y + 5, WHITE if sel else CYAN, "c")

    def fondo(self, mover=True):
        """Espacio + piso que se mueve (para los menus)."""
        self.background.tick()
        if not mover:
            v, self.floor.vel_x = self.floor.vel_x, 0
            self.floor.tick()
            self.floor.vel_x = v
        else:
            self.floor.tick()

    def oscurecer(self, alfa=175):
        capa = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
        capa.fill((7, 6, 20, alfa))
        self.config.screen.blit(capa, (0, 0))

    def tabla(self, titulo, y=4):
        """Marco grande con titulo (leaderboard, estadisticas, etc.)."""
        self.oscurecer()
        img = self.config.images.tabla
        x = (ANCHO - img.get_width()) // 2
        self.config.screen.blit(img, (x, y))
        self.texto(titulo, ANCHO // 2, y + 4, CYAN, "c")
        return x, y

    def pie(self, t, y=ALTO - 13):
        """Texto de ayuda sobre el piso."""
        if t and (self.t // 30) % 4:
            self.texto(t, ANCHO // 2, y, BLUE, "c", NAVY)
