"""
MENU PRINCIPAL: las opciones salen de la tabla MENU_OPCION.
"""
import math

from ..utils.constants import BLUE, CYAN, GOLD
from .comun import Lista


class MenuPantalla:
    async def menu_principal(self):
        ops = self.bd.opciones("PRINCIPAL")
        lista = Lista(ops, 8, paso=18, x=250, sel=getattr(self, "sel_menu", 0))
        record = self.bd.record(self.uid)
        alias = self.bd.usuario(self.uid)[1]
        img = self.config.images
        self.config.sounds.tocar("menu")

        def manejar(e):
            r = lista.manejar(e, self.mouse, self.config.sounds)
            if r == "ATRAS":                       # ESC lleva el cursor a SALIR
                lista.sel = len(ops) - 1
                return None
            return None if r is None else ops[r]

        def dibujar():
            self.fondo()
            self.config.screen.blit(img.titulo, (22, 22 + int(math.sin(self.t * 0.04) * 2)))
            nave = img.player[1]
            y = 92 + int(math.sin(self.t * 0.08) * 3)
            self.config.screen.blit(img.fuego[(self.t // 4) % 2], (60, y + 5))
            self.config.screen.blit(nave, (62, y))
            self.texto("JUGADOR: " + alias, 75, 118, CYAN, "c")
            self.texto("RECORD: %d" % record, 75, 130, GOLD, "c")
            lista.dibujar(self, self.t)
            self.pie("FLECHAS + ENTER  O  CLIC", 167)
            self.texto("BASES DE DATOS", 75, 146, BLUE, "c")

        r = await self.pantalla("PRINCIPAL", manejar, dibujar)
        self.sel_menu = lista.sel
        return r
