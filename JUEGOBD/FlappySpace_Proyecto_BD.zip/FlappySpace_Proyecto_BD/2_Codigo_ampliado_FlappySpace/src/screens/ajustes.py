"""
AJUSTES: volumen, musica, pantalla completa, FPS y nave preferida (tabla AJUSTES, 1 por usuario).
"""
import pygame
from pygame.locals import KEYDOWN, MOUSEBUTTONDOWN, MOUSEMOTION

from ..utils.constants import ANCHO, BLUE, CYAN, GOLD, WHITE
from .comun import ABAJO, ACEPTAR, ARRIBA


class AjustesPantalla:
    def aplicar_ajustes(self):
        a = self.ajustes
        self.config.sounds.volumen = a["volumen"] / 100
        self.config.sounds.volumen_musica(a["musica"] / 100)
        self.config.window.cambiar_pantalla(a["pantalla"])

    async def menu_ajustes(self):
        ops = self.bd.opciones("AJUSTES")       # EFECTOS, MUSICA, PANTALLA COMPLETA, MOSTRAR FPS, NAVE, VOLVER
        naves = [(None, "ALEATORIA", None)] + list(self.bd.naves())
        a = self.ajustes
        sel = [0]
        filas = lambda i: pygame.Rect(80, 24 + i * 18, 160, 14)

        def valor(op):
            if op in ("EFECTOS", "MUSICA"):
                return "%d%%" % a["volumen" if op == "EFECTOS" else "musica"]
            if op == "PANTALLA COMPLETA":
                return "SI" if a["pantalla"] else "NO"
            if op == "MOSTRAR FPS":
                return "SI" if a["fps"] else "NO"
            if op == "NAVE":
                return next(p[1] for p in naves if p[0] == a["nave"])
            return ""

        def cambiar(op, d):
            if op in ("EFECTOS", "MUSICA"):
                k = "volumen" if op == "EFECTOS" else "musica"
                a[k] = max(0, min(100, a[k] + 10 * d))
            elif op == "PANTALLA COMPLETA":
                a["pantalla"] = not a["pantalla"]
            elif op == "MOSTRAR FPS":
                a["fps"] = not a["fps"]
            elif op == "NAVE":
                i = [p[0] for p in naves].index(a["nave"])
                a["nave"] = naves[(i + d) % len(naves)][0]
            self.aplicar_ajustes()
            self.bd.guardar_ajustes(self.uid, a)
            self.config.sounds.mover.play()

        def manejar(e):
            op = ops[sel[0]]
            if e.type == KEYDOWN:
                if e.key in ARRIBA or e.key in ABAJO:
                    sel[0] = (sel[0] + (-1 if e.key in ARRIBA else 1)) % len(ops)
                    self.config.sounds.mover.play()
                elif e.key in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_a, pygame.K_d) and op != "VOLVER":
                    cambiar(op, 1 if e.key in (pygame.K_RIGHT, pygame.K_d) else -1)
                elif e.key in ACEPTAR:
                    if op == "VOLVER":
                        return "VOLVER"
                    cambiar(op, 1)
                elif e.key == pygame.K_ESCAPE:
                    return "VOLVER"
            elif e.type == MOUSEMOTION:
                for i in range(len(ops)):
                    if filas(i).collidepoint(self.mouse):
                        sel[0] = i
            elif e.type == MOUSEBUTTONDOWN and e.button == 1:
                for i, op in enumerate(ops):
                    if filas(i).collidepoint(self.mouse):
                        sel[0] = i
                        if op == "VOLVER":
                            return "VOLVER"
                        cambiar(op, 1)
            return None

        def dibujar():
            self.fondo()
            self.oscurecer()
            self.texto("AJUSTES", ANCHO // 2, 8, CYAN, "c")
            img = self.config.images
            for i, op in enumerate(ops):
                r = filas(i)
                self.config.screen.blit(img.campo_sel if i == sel[0] else img.campo, (r.x, r.y))
                color = WHITE if i == sel[0] else CYAN
                if op == "VOLVER":
                    self.texto(op, ANCHO // 2, r.y + 4, color, "c")
                else:
                    self.texto(op, r.x + 4, r.y + 4, color)
                    self.texto(valor(op), r.right - 4, r.y + 4, GOLD, "d")
            # muestra la nave elegida (si es aleatoria, van pasando todas)
            carpeta = next(p[2] for p in naves if p[0] == a["nave"]) or naves[1 + self.t // 60 % (len(naves) - 1)][2]
            y = 132 + (self.t // 20) % 2
            self.config.screen.blit(img.fuego[(self.t // 4) % 2], (ANCHO // 2 - 13, y + 5))
            self.config.screen.blit(img.nave(carpeta)[1], (ANCHO // 2 - 11, y))
            self.texto("IZQ/DER: CAMBIAR VALOR  (SE GUARDA SOLO EN LA BD)", ANCHO // 2, 148, BLUE, "c")
            self.pie("ESC: VOLVER")

        await self.pantalla("AJUSTES", manejar, dibujar)
