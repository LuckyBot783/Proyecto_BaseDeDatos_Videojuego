"""
PANTALLAS DE CONSULTA: LEADERBOARD, ESTADISTICAS, CONTROLES y CREDITOS.
Todas leen la base de datos y se cambian de pagina con IZQUIERDA/DERECHA.
"""
import pygame
from pygame.locals import KEYDOWN, MOUSEBUTTONDOWN

from ..utils.constants import ANCHO, BLUE, CYAN, DEEP, GOLD, LIME, MAG, NAVY, PINK, SKY, WHITE

CREDITOS = [
    ("FLAPPY SPACE", GOLD), ("PROYECTO FINAL DE BASES DE DATOS", CYAN), ("", None),
    ("EQUIPO", MAG), ("JULIO DAVILA ACEVEDO", WHITE), ("LUIS FERNANDO SILVA BRIONES", WHITE),
    ("ERICK LEONARDO CHAVEZ PONCE", WHITE), ("", None),
    ("PROFESOR: DR. JAIME MUNOZ ARTEAGA", CYAN), ("UAA - I.C.I. - 5 SEMESTRE - AGO/DIC 2026", BLUE), ("", None),
    ("CODIGO BASE: FLAPPYBIRD DE SOURABH VERMA (MIT)", SKY), ("GITHUB.COM/SOURABHV/FLAPPYBIRD", BLUE),
]
MEDALLA_IMG = {1: "bronce", 2: "plata", 3: "oro", 4: "platino"}


def tiempo(seg):
    """Segundos a M:SS (o H:MM:SS si pasa de una hora)."""
    seg = int(seg)
    if seg >= 3600:
        return "%d:%02d:%02d" % (seg // 3600, seg % 3600 // 60, seg % 60)
    return "%d:%02d" % (seg // 60, seg % 60)


def fecha(f):
    return f[8:10] + "/" + f[5:7] + "/" + f[2:4] if f else "-"


class TablasPantalla:
    async def paginas(self, clave, n, dibujar):
        """Bucle comun: IZQ/DER o clic cambian de pagina; ESC/ENTER regresan."""
        pag = [0]

        def manejar(e):
            if e.type == KEYDOWN and e.key in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_a, pygame.K_d):
                pag[0] = (pag[0] + (1 if e.key in (pygame.K_RIGHT, pygame.K_d) else -1)) % n
                self.config.sounds.mover.play()
            elif e.type == MOUSEBUTTONDOWN and e.button == 1 and n > 1:
                pag[0] = (pag[0] + 1) % n
                self.config.sounds.mover.play()
            elif e.type == KEYDOWN and e.key in (pygame.K_ESCAPE, pygame.K_RETURN, pygame.K_KP_ENTER):
                self.config.sounds.atras.play()
                return "VOLVER"
            return None

        def todo():
            self.fondo()
            dibujar(pag[0])
            self.pie("IZQ/DER: PAGINA %d DE %d     ESC: VOLVER" % (pag[0] + 1, n) if n > 1 else "ESC: VOLVER")

        await self.pantalla(clave, manejar, todo)

    def fila(self, x, y, i, mio=False):
        """Fondo alternado de un renglon (y resaltado si es del jugador actual)."""
        if mio or i % 2 == 0:
            self.config.screen.fill(DEEP if mio else NAVY, (x + 1, y - 2, 298, 11))

    # ------------------------------------------------------------------ LEADERBOARD
    async def leaderboard(self):
        vistas = self.bd.opciones("LEADERBOARD")       # MEJORES PARTIDAS / MEJORES JUGADORES
        partidas, jugadores = self.bd.top_partidas(), self.bd.top_jugadores()
        medalla = {f[0]: self.bd.medalla_para(f[2]) for f in partidas}
        rango = {1: GOLD, 2: CYAN, 3: PINK}

        def dibujar(p):
            x, y = self.tabla(vistas[p])
            cols = ([("#", 14, "d"), ("ALIAS", 24, "i"), ("PTS", 116, "d"), ("MEDALLA", 124, "i"),
                     ("NAVE", 186, "i"), ("FECHA", 290, "d")] if p == 0 else
                    [("#", 14, "d"), ("ALIAS", 24, "i"), ("RECORD", 140, "d"), ("PARTIDAS", 214, "d"),
                     ("PUNTOS", 290, "d")])
            for txt, cx, al in cols:
                self.texto(txt, x + cx, y + 18, BLUE, al)
            filas = partidas if p == 0 else jugadores
            if not filas:
                self.texto("AUN NO HAY PARTIDAS: JUEGA PARA SER EL PRIMERO!", ANCHO // 2, 80, MAG, "c")
            for i, f in enumerate(filas):
                yy = y + 31 + i * 11
                mio = f[4 if p == 0 else 0] == self.uid
                self.fila(x, yy, i, mio)
                self.texto(str(i + 1), x + 14, yy, rango.get(i + 1, BLUE), "d")
                self.texto(f[1], x + 24, yy, WHITE)
                if p == 0:
                    self.texto(str(f[2]), x + 116, yy, CYAN, "d")
                    m = medalla[f[0]]
                    if m:
                        ico = pygame.transform.scale(self.config.images.medallas[MEDALLA_IMG[m[0]]], (8, 8))
                        self.config.screen.blit(ico, (x + 124, yy - 1))
                        self.texto(m[1], x + 134, yy, GOLD)
                    self.texto(f[5], x + 186, yy, PINK)
                    self.texto(fecha(f[3]), x + 290, yy, BLUE, "d")
                else:
                    self.texto(str(f[2]), x + 140, yy, CYAN, "d")
                    self.texto(str(f[3]), x + 214, yy, PINK, "d")
                    self.texto(str(f[4]), x + 290, yy, GOLD, "d")

        await self.paginas("LEADERBOARD", 2, dibujar)

    # ------------------------------------------------------------------ ESTADISTICAS
    async def estadisticas(self):
        paginas = self.bd.opciones("ESTADISTICAS")
        self.rastreo.guardar()                         # que cuenten los clics de hace un momento
        d = self.bd.estadisticas(self.uid)
        todos = self.bd.estadisticas_todos()
        medallas = self.bd.medallas_usuario(self.uid)
        izquierda = [
            ("II.A PROGRESO", None), ("ID USUARIO", d["id_usuario"]), ("ALIAS", d["alias"]),
            ("PARTIDAS", d["partidas"]), ("TIEMPO JUEGO", tiempo(d["tiempo_juego_seg"])),
            ("TIEMPO SESION", tiempo(d["tiempo_sesiones"])), ("", ""),
            ("II.C COMPORTAMIENTO", None), ("CLICS/TOQUES", d["clics"]), ("TECLAS", d["teclas"]),
            ("ACCIONES MENU", d["interacciones_menu"]), ("VISITAS MENU", d["menus_abiertos"]),
        ]
        derecha = [
            ("II.B DESEMPENO", None), ("PUNTOS TOTAL", d["puntos_acumulados"]), ("RECORD", d["record"]),
            ("VICTORIAS", d["victorias"]), ("DERROTAS", d["derrotas"]), ("RELACION V/D", "%.2f" % d["relacion"]),
        ]

        def columna(filas, x0, y0):
            for i, (k, v) in enumerate(filas):
                yy = y0 + i * 10
                if v is None:
                    self.texto(k, x0, yy, MAG)
                elif k:
                    self.texto(k, x0 + 4, yy, CYAN)
                    self.texto(str(v), x0 + 138, yy, LIME if k in ("VICTORIAS", "RECORD") else WHITE, "d")

        def dibujar(p):
            x, y = self.tabla(paginas[p])
            if p == 0:
                self.texto(d["nombre_completo"], ANCHO // 2, y + 18, GOLD, "c")
                columna(izquierda, x + 8, y + 30)
                columna(derecha, x + 154, y + 30)
                self.texto("VICTORIA = SUPERAR", x + 158, y + 100, BLUE)
                self.texto("TU RECORD ANTERIOR", x + 158, y + 110, BLUE)
            elif p == 1:
                cols = (("ALIAS", 8, "i"), ("PARTIDAS", 110, "d"), ("PUNTOS", 160, "d"),
                        ("VICTORIAS", 225, "d"), ("DERROTAS", 290, "d"))
                for txt, cx, al in cols:
                    self.texto(txt, x + cx, y + 18, BLUE, al)
                for i, fila in enumerate(todos[:11]):
                    yy = y + 31 + i * 10
                    self.fila(x, yy, i, fila[0] == d["alias"])
                    for (txt, cx, al), v in zip(cols, fila):
                        self.texto(str(v), x + cx, yy, WHITE if cx == 8 else CYAN, al)
            else:
                for i, (nombre, minimo, archivo, veces, fecha_m) in enumerate(medallas):
                    cx = x + 39 + i * 74
                    img = self.config.images.medallas[archivo[8:-4]]
                    if not veces:                       # sin obtener: se ve oscura
                        img = img.copy()
                        img.fill((90, 90, 120, 255), special_flags=pygame.BLEND_RGBA_MULT)
                    self.config.screen.blit(pygame.transform.scale(img, (32, 32)), (cx - 16, y + 26))
                    self.texto(nombre, cx, y + 66, GOLD if veces else BLUE, "c")
                    self.texto("%d PUNTOS" % minimo, cx, y + 78, CYAN, "c")
                    self.texto("X%d" % veces if veces else "NO OBTENIDA", cx, y + 92, LIME if veces else MAG, "c")
                    self.texto(fecha(fecha_m) if veces else "", cx, y + 104, BLUE, "c")

        await self.paginas("ESTADISTICAS", len(paginas), dibujar)

    # ------------------------------------------------------------------ CONTROLES
    async def controles(self):
        grupos = self.bd.controles()                   # MENU_TECLA + TECLA

        def dibujar(p):
            nombre, teclas = grupos[p]
            x, y = self.tabla("CONTROLES")
            self.texto("PANTALLA: " + nombre, ANCHO // 2, y + 18, GOLD, "c")
            self.texto("ACCION", x + 40, y + 31, BLUE)
            self.texto("TECLA / BOTON", x + 260, y + 31, BLUE, "d")
            for i, (tecla, accion) in enumerate(teclas):
                yy = y + 43 + i * 11
                self.fila(x, yy, i)
                self.texto(accion, x + 40, yy, WHITE)
                self.texto(tecla, x + 260, yy, CYAN, "d")

        await self.paginas("CONTROLES", len(grupos), dibujar)

    # ------------------------------------------------------------------ CREDITOS
    async def creditos(self):
        def dibujar(p):
            x, y = self.tabla("CREDITOS")
            for i, (linea, color) in enumerate(CREDITOS):
                if linea:
                    self.texto(linea, ANCHO // 2, y + 22 + i * 9, color, "c")

        await self.paginas("CREDITOS", 1, dibujar)
