from .ajustes import AjustesPantalla
from .comun import Comun, Lista
from .login import LoginPantalla
from .menu import MenuPantalla
from .tablas import TablasPantalla
