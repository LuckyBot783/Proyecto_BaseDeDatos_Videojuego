"""
LOGIN y REGISTRO: elegir quien juega o crear un jugador nuevo (tabla USUARIO).
"""
import pygame
from pygame.locals import KEYDOWN, MOUSEBUTTONDOWN

from ..utils import limpiar
from ..utils.constants import ANCHO, BLUE, CYAN, LIME, MAG, WHITE
from .comun import ABAJO, ARRIBA, Lista

CAMPOS = (("ALIAS", 8), ("NOMBRE", 12), ("APELLIDO", 12))


class LoginPantalla:
    async def login(self):
        """Se repite hasta que haya un jugador elegido."""
        while self.uid is None:
            usuarios = self.bd.usuarios()
            if not usuarios:
                uid = await self.registro(puede_cancelar=False)
            else:
                ops = [alias for _, alias in usuarios] + self.bd.opciones("LOGIN")
                lista = Lista(ops, 26, visibles=7)

                def manejar(e):
                    r = lista.manejar(e, self.mouse, self.config.sounds)
                    return "SALIR" if r == "ATRAS" else None if r is None else ops[r]

                def dibujar():
                    self.fondo()
                    self.oscurecer(120)
                    self.texto("QUIEN VA A JUGAR?", ANCHO // 2, 10, CYAN, "c")
                    lista.dibujar(self, self.t)
                    if len(ops) > lista.visibles:
                        self.texto("%d JUGADORES" % len(usuarios), 312, 148, BLUE, "d")
                    self.pie("ENTER: ELEGIR     ESC: SALIR")

                r = await self.pantalla("LOGIN", manejar, dibujar)
                if r == "SALIR":
                    self.salir()
                uid = (await self.registro(True) if r == "NUEVO JUGADOR"
                       else dict((a, i) for i, a in usuarios)[r])
            if uid:
                self.iniciar_sesion(uid)

    async def registro(self, puede_cancelar):
        """Captura alias, nombre y apellido. Devuelve el id nuevo o None si se cancela."""
        valores = ["", "", ""]
        estado = {"campo": 0, "msg": "ESCRIBE TUS DATOS", "ok": True}
        y_campo = [32, 54, 76]
        boton = pygame.Rect(200 - 44, 100, 88, 16)

        def crear():
            alias, nombre, apellido = (v.strip() for v in valores)
            error = ("FALTA EL ALIAS" if not alias else "FALTA EL NOMBRE" if not nombre
                     else "FALTA EL APELLIDO" if not apellido
                     else "ESE ALIAS YA EXISTE" if self.bd.alias_existe(alias) else None)
            if error:
                estado.update(msg=error, ok=False)
                self.config.sounds.atras.play()
                return None
            self.config.sounds.record.play()
            return self.bd.crear_usuario(alias, nombre, apellido)

        def manejar(e):
            c = estado["campo"]
            if e.type == KEYDOWN:
                if e.key == pygame.K_ESCAPE and puede_cancelar:
                    self.config.sounds.atras.play()
                    return "CANCELAR"
                if e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    if c < 3:
                        estado["campo"] = c + 1
                        self.config.sounds.mover.play()
                    else:
                        return crear()
                elif e.key == pygame.K_TAB or e.key in ABAJO[:1]:
                    estado["campo"] = (c + 1) % 4
                elif e.key in ARRIBA[:1]:
                    estado["campo"] = (c - 1) % 4
                elif e.key == pygame.K_BACKSPACE and c < 3:
                    valores[c] = valores[c][:-1]
                elif c < 3 and e.unicode:
                    ch = limpiar(e.unicode)
                    permitido = ch.isalnum() if c == 0 else (ch.isalpha() or (ch == " " and valores[c]))
                    if permitido and len(ch) == 1 and len(valores[c]) < CAMPOS[c][1]:
                        valores[c] += ch
            elif e.type == MOUSEBUTTONDOWN and e.button == 1:
                for i, y in enumerate(y_campo):
                    if pygame.Rect(120, y, 160, 14).collidepoint(self.mouse):
                        estado["campo"] = i
                if boton.collidepoint(self.mouse):
                    estado["campo"] = 3
                    return crear()
            return None

        def dibujar():
            self.fondo()
            self.oscurecer()
            self.texto("NUEVO JUGADOR", ANCHO // 2, 10, CYAN, "c")
            img = self.config.images
            for i, ((nombre, largo), y) in enumerate(zip(CAMPOS, y_campo)):
                sel = estado["campo"] == i
                self.texto(nombre, 112, y + 4, WHITE if sel else CYAN, "d")
                self.texto("MAX %d" % largo, 284, y + 4, BLUE)
                self.config.screen.blit(img.campo_sel if sel else img.campo, (120, y))
                cursor = "_" if sel and (self.t // 20) % 2 == 0 else ""
                self.texto(valores[i] + cursor, 124, y + 4, WHITE)
            self.boton("CREAR", boton.centerx, boton.y, estado["campo"] == 3)
            self.texto(estado["msg"], ANCHO // 2, 124, LIME if estado["ok"] else MAG, "c")
            self.texto("TAB / FLECHAS: CAMBIAR DE CAMPO    ENTER: SIGUIENTE", ANCHO // 2, 138, BLUE, "c")
            self.pie("ESC: CANCELAR" if puede_cancelar else "BIENVENIDO A FLAPPY SPACE!")

        r = await self.pantalla("REGISTRO", manejar, dibujar)
        return None if r == "CANCELAR" else r
