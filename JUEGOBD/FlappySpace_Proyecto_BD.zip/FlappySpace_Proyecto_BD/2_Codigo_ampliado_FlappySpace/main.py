"""
FLAPPY SPACE - Proyecto final de Bases de Datos
Codigo base: FlapPyBird de Sourabh Verma (MIT) https://github.com/sourabhv/FlapPyBird
Ejecutar:  py main.py      (necesita: py -m pip install pygame-ce)

Estructura (se respeto la del codigo original y se agrego lo NUEVO):
  src/flappy.py        clase Flappy: login -> menu -> partida (splash, play, game_over)
  src/entities/        objetos del juego (nave, tubos, piso, fondo, puntaje...)
  src/utils/           configuracion, imagenes, sonidos, ventana, texto pixel
  src/screens/         NUEVO: pantallas de login, menu, leaderboard, estadisticas, ajustes...
  src/database/        NUEVO: base de datos SQLite (esquema, datos, consultas, rastreo)

La base de datos (flappy_space_bd.db) se crea sola junto a este archivo (o junto al .exe).
"""
import asyncio
import os
import sys

from src.flappy import Flappy

if __name__ == "__main__":
    if getattr(sys, "frozen", False):                      # .exe hecho con PyInstaller
        carpeta_bd = os.path.dirname(sys.executable)
        os.chdir(sys._MEIPASS)
    else:
        carpeta_bd = os.path.dirname(os.path.abspath(__file__))
        os.chdir(carpeta_bd)                               # los assets se buscan desde aqui
    asyncio.run(Flappy(os.path.join(carpeta_bd, "flappy_space_bd.db")).start())
